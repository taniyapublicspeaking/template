# Changelog — Question Presenter v1.2.1

## CSV validation reliability patch

- Accurate blank-row accounting, including whitespace-only rows and blank-only files; terminal newlines do not create phantom rows.
- Warnings for gaps and backwards/out-of-order numeric question numbering.
- Duplicate header detection for both literal duplicates and equivalent aliases (such as `Question` and `Question text`).
- Clear warnings for rows with too few or too many cells.
- Rows with extra cells are skipped to avoid silently truncating question or answer text. Rows with fewer cells are warned about; absent trailing optional cells are treated as blank when required Question and Answer fields remain present.
- Focused Chromium regression tests cover each fix and verify import cancellation/confirmation behaviour.
- Existing question bank remains unchanged until import is confirmed.
