from pathlib import Path
from playwright.sync_api import sync_playwright
import json, sys
HTML=(Path(__file__).resolve().parents[1] / 'question-presenter-v1.2.1.html').read_text()
HTML=HTML.rsplit('})();',1)[0] + 'window.__csvTest={validateCSVText,parseCSVDetailed,beginCSVValidation,getBank:()=>bank};})();' + HTML.rsplit('})();',1)[1]
results=[]
def check(name, condition, detail=''):
    results.append({'test':name,'result':'PASS' if condition else 'FAIL','detail':detail})
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page()
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(HTML, wait_until='domcontentloaded')
    page.wait_for_timeout(250)
    # Blank row counts: internal blank and whitespace-only lines; terminal newline must not add an extra blank row.
    report=page.evaluate("""() => __csvTest.validateCSVText('Question number,Question,Answer\\n1,What is 1?,One\\n\\n2,What is 2?,Two\\n   \\n3,What is 3?,Three\\n','blank-test.csv')""")
    check('Accurate blank-row counting', report['counts']['empty']==2, f"expected 2 blank rows, got {report['counts']['empty']}")
    check('Trailing line terminator not counted as blank row', report['counts']['empty']==2, f"trailing newline excluded; count={report['counts']['empty']}")
    # Non-sequential numbering warning.
    report=page.evaluate("""() => __csvTest.validateCSVText('Question number,Question,Answer\\n1,Q1,A1\\n3,Q3,A3\\n4,Q4,A4\\n','numbering.csv')""")
    check('Non-sequential question numbers warned', report['counts']['numbering']==1 and any('jumps from 1 to 3' in w['message'] for w in report['warnings']), json.dumps({'numbering':report['counts']['numbering'],'warnings':report['warnings']}))
    # Backward sequence warning.
    report=page.evaluate("""() => __csvTest.validateCSVText('Question number,Question,Answer\\n1,Q1,A1\\n3,Q3,A3\\n2,Q2,A2\\n','backwards.csv')""")
    check('Out-of-order numbering warned', report['counts']['numbering']==2 and any('goes backwards from 3 to 2' in w['message'] for w in report['warnings']), json.dumps({'numbering':report['counts']['numbering']}))
    # Exact and alias duplicate headers.
    report=page.evaluate("""() => __csvTest.validateCSVText('Question, Question ,Question text,Answer,Answer\\nQ,Q2,Q3,A,A2\\n','duplicate-headers.csv')""")
    check('Duplicate exact and equivalent headers detected', report['counts']['duplicateHeaders']>=1 and any('Duplicate or equivalent header' in w['message'] for w in report['warnings']), json.dumps({'duplicateHeaders':report['counts']['duplicateHeaders'],'warnings':report['warnings']}))
    # Inconsistent row width both missing and extra cells.
    report=page.evaluate("""() => __csvTest.validateCSVText('Question number,Question,Answer\\n1,Q1,A1\\n2,Q2\\n3,Q3,A3,EXTRA\\n','width.csv')""")
    check('Short and long rows flagged', report['counts']['width']==2 and any('cell(s) missing' in w['message'] for w in report['warnings']) and any('extra cell(s)' in w['message'] for w in report['warnings']), json.dumps({'width':report['counts']['width'],'warnings':report['warnings']}))
    check('Rows missing required fields or with extra cells are skipped', report['counts']['invalid']==2 and len(report['candidate'])==1, json.dumps({'valid':len(report['candidate']),'invalid':report['counts']['invalid']}))
    # Blank-only file reports count and critical failure.
    report=page.evaluate("""() => __csvTest.validateCSVText('\\n\\n','empty.csv')""")
    check('Blank-only file reports blank rows and blocks import', report['critical'] and report['counts']['empty']==2, json.dumps({'critical':report['critical'],'empty':report['counts']['empty']}))
    # Existing bank is preserved when import is cancelled.
    page.evaluate("""() => { __csvTest.beginCSVValidation('Question number,Question,Answer\\n1,Replacement question,Replacement answer\\n','cancel-test.csv'); }""")
    before=page.evaluate('__csvTest.getBank().length')
    page.locator('#cancelCsv').click()
    after=page.evaluate('__csvTest.getBank().length')
    check('Cancel preserves current question bank', before==after, f'before={before}, after={after}')
    # Confirm loads validated rows and skips incomplete rows.
    page.evaluate("""() => { __csvTest.beginCSVValidation('Question number,Question,Answer\\n1,New question,New answer\\n2,,Missing question\\n','confirm-test.csv'); }""")
    page.locator('#acceptCsv').click()
    state=page.evaluate("""() => ({count:__csvTest.getBank().length,first:__csvTest.getBank()[0]?.question,answer:__csvTest.getBank()[0]?.answer,reviewHidden:document.getElementById('csvReview').classList.contains('hidden')})""")
    check('Confirm imports valid rows only', state['count']==1 and state['first']=='New question' and state['answer']=='New answer' and state['reviewHidden'], json.dumps(state))
    check('No browser page errors', len(errors)==0, '; '.join(errors))
    browser.close()
print(json.dumps(results, indent=2))
failed=[x for x in results if x['result']!='PASS']
print(f"SUMMARY: {len(results)-len(failed)}/{len(results)} passed")
sys.exit(1 if failed else 0)
