# Question Presenter v1.2.0


## CSV validation follow-up

The latest reliability patch strengthens CSV validation:

- Blank rows are counted accurately; a terminal newline does not create a phantom blank row.
- Numeric question numbering gaps and backwards ordering are warned about.
- Duplicate headers are detected both literally and through equivalent aliases.
- Short and long rows are identified. Rows with extra cells are skipped to avoid silent text truncation; missing trailing cells are treated as blank only when required fields remain available.

Run the focused regression suite from this release folder with Python, Playwright, and Chromium installed:

```bash
python tests/test_csv_validation.py
```

The test suite launches Chromium from `/usr/bin/chromium` by default; adjust that path in the test script if Chromium is installed elsewhere.


## v1.2.1 CSV validation patch

This patch corrects blank-row counts, adds numbering sequence warnings, detects duplicate/equivalent headers, and handles row-width mismatches safely. Rows with extra cells are skipped to prevent silent truncation; short rows are warned about and only imported if the required Question and Answer fields are present.

Run the regression suite with Python, Playwright, and Chromium installed:

```bash
python tests/test_csv_validation.py
```

The test script defaults to `/usr/bin/chromium`; adjust the executable path if needed.
