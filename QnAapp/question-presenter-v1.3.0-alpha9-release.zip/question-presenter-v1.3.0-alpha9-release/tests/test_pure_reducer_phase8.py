from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'question-presenter-v1.3.0-alpha8.html').read_text()
needle='})();\n</script>'
assert needle in SRC
HOOK='''window.__phase8={
  getState:()=>selectLessonState(),getQuestions:()=>selectQuestions(),getIndex:()=>selectQuestionIndex(),
  getMode:()=>selectMode(),getQuestion:()=>selectQuestion(),getPhase:()=>selectQuestionPhase(),
  isRunning:()=>selectIsRunning(),isPaused:()=>selectIsPaused(),getTimer:()=>selectTimerState(),getSpeech:()=>selectSpeechState(),
  dispatch:dispatchLessonAction,command:dispatchLessonCommand,start,pause,next,go,reveal,stop,resume,finish,
  repeatCompletedLesson,beginReviewSession,resetSettings,replaceQuestions,setQuestionIndex,setLearningMode,
  setQuestionPhase,setAnswerVisible,setExplanationVisible,SpeechEffects,getSpeechSequence:()=>speechSequence
};
})();
</script>'''
HTML=Path('/tmp/question-presenter-v1.3.0-alpha8-phase8-test.html')
HTML.write_text(SRC.replace(needle,HOOK,1))
results=[]
def check(name,fn):
    try: results.append((name,'PASS',str(fn())))
    except Exception as e: results.append((name,'FAIL',str(e)))
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(HTML.read_text(),wait_until='domcontentloaded')
    def reset(): page.set_content(HTML.read_text(),wait_until='domcontentloaded')
    def test_no_compatibility_accessors_or_accessor_declarations():
        assert 'Object.defineProperties(globalThis' not in SRC
        for name in ['list','i','mode','phase','revealed','explanationVisible','running','paused']:
            assert not re.search(r'\b'+name+r'\s*:\s*\{\s*configurable\s*:',SRC),name
        r=page.evaluate("()=>['list','i','mode','phase','revealed','explanationVisible','running','paused'].map(k=>{const d=Object.getOwnPropertyDescriptor(window,k);return {key:k,get:typeof d?.get,set:typeof d?.set}})")
        assert all(x['get']=='undefined' and x['set']=='undefined' for x in r),r
        return 'No compatibility property accessors remain'
    def test_runtime_reads_use_selectors_and_writes_use_actions():
        script=SRC.split('<script>',1)[1].split('</script>',1)[0]
        runtime=script[script.index('function cur(){return selectQuestion()}'):]
        for pattern in [r'\blist\s*=(?!=)',r'\bi\s*=(?!=)',r'\bmode\s*=(?!=)',r'\bphase\s*=(?!=)',r'\brevealed\s*=(?!=)',r'\bexplanationVisible\s*=(?!=)']:
            assert not re.search(pattern,runtime),pattern
        for name in ['selectQuestions()','selectQuestionIndex()','selectMode()','selectQuestionPhase()','selectAnswerVisible()','selectExplanationVisible()','selectIsRunning()','selectIsPaused()']:
            assert name in runtime,name
        for name in ['replaceQuestions(','setQuestionIndex(','setLearningMode(','setQuestionPhase(','setAnswerVisible(','setExplanationVisible(']:
            assert name in runtime,name
        return 'Runtime reads use selectors and state writes use explicit reducer actions'
    def test_selector_actions_are_authoritative_and_validated():
        r=page.evaluate('''()=>{const t=window.__phase8;t.replaceQuestions([{question:'A',answer:'a'},{question:'B',answer:'b'}]);t.setQuestionIndex(1);t.setLearningMode('teacher');t.setQuestionPhase('answer');t.setAnswerVisible(true);t.setExplanationVisible(true);const good={count:t.getQuestions().length,index:t.getIndex(),mode:t.getMode(),question:t.getQuestion().question,phase:t.getPhase(),visible:t.getState().question.answerVisible,explanation:t.getState().question.explanationVisible};t.setQuestionIndex(99);t.setLearningMode('bogus');return {...good,invalidIndex:t.getIndex(),invalidMode:t.getMode()}}''')
        assert r=={'count':2,'index':1,'mode':'teacher','question':'B','phase':'answer','visible':True,'explanation':True,'invalidIndex':1,'invalidMode':'teacher'},r;return r
    def test_start_reveal_next_previous_and_restart():
        reset();page.locator('#start').click();page.locator('#reveal').click();a=page.evaluate("()=>({index:__phase8.getIndex(),phase:__phase8.getPhase(),visible:__phase8.getState().question.answerVisible})");page.locator('#next').click();page.locator('#prev').click();b=page.evaluate("()=>({index:__phase8.getIndex(),phase:__phase8.getPhase(),visible:__phase8.getState().question.answerVisible})");page.locator('#restartQ').click();c=page.evaluate("()=>({index:__phase8.getIndex(),phase:__phase8.getPhase(),visible:__phase8.getState().question.answerVisible})")
        assert a=={'index':0,'phase':'answer','visible':True} and b=={'index':0,'phase':'question','visible':False} and c==b,(a,b,c);return {'revealed':a,'navigation':b,'restart':c}
    def test_pause_resume_timer_state():
        reset();page.locator('#mode').select_option('timed');page.locator('#start').click();page.locator('#pause').click();a=page.evaluate("()=>({status:__phase8.getState().status,timer:__phase8.getTimer().status,paused:__phase8.isPaused()})");page.locator('#pause').click();b=page.evaluate("()=>({status:__phase8.getState().status,timer:__phase8.getTimer().status,paused:__phase8.isPaused()})")
        assert a['status']=='paused' and a['paused'] and a['timer'] in ('paused','idle'),a;assert b['status']=='running' and not b['paused'] and b['timer'] in ('running','idle'),b;return {'paused':a,'resumed':b}
    def test_stop_and_continue_restore_question():
        reset();page.locator('#start').click();page.locator('#next').click();page.locator('#stop').click();stopped=page.evaluate("()=>({status:__phase8.getState().status,index:__phase8.getIndex(),checkpoint:__phase8.getState().checkpoint.available})");page.locator('#resume').click();continued=page.evaluate("()=>({status:__phase8.getState().status,index:__phase8.getIndex()})")
        assert stopped=={'status':'stopped','index':1,'checkpoint':True},stopped;assert continued=={'status':'running','index':1},continued;return {'stopped':stopped,'continued':continued}
    def test_completion_and_replay():
        reset();page.locator('#start').click();page.evaluate("()=>__phase8.dispatch({type:'QUESTION/SET_INDEX',index:__phase8.getQuestions().length-1})");page.locator('#next').click();done=page.evaluate("()=>({status:__phase8.getState().status,phase:__phase8.getPhase(),visible:!document.querySelector('#done').classList.contains('hidden')})");page.locator('#again').click();again=page.evaluate("()=>({status:__phase8.getState().status,index:__phase8.getIndex(),phase:__phase8.getPhase(),visible:!document.querySelector('#done').classList.contains('hidden')})")
        assert done=={'status':'completed','phase':'complete','visible':True},done;assert again=={'status':'running','index':0,'phase':'question','visible':False},again;return {'completed':done,'replayed':again}
    def test_review_starts_in_revision_mode_with_subset():
        reset();page.locator('#start').click();subset=page.evaluate("()=>__phase8.getQuestions().slice(1,3)");page.evaluate("subset=>__phase8.beginReviewSession(subset,'Phase 8 review')",subset);r=page.evaluate("()=>({status:__phase8.getState().status,mode:__phase8.getMode(),index:__phase8.getIndex(),count:__phase8.getQuestions().length,first:__phase8.getQuestion().question})")
        assert r['status']=='running' and r['mode']=='revision' and r['index']==0 and r['count']==2,r;return r
    def test_navigation_invalidates_old_narration_sequence():
        reset();page.locator('#qVoice').check();page.locator('#start').click();before=page.evaluate('()=>__phase8.getSpeechSequence()');page.locator('#next').click();after=page.evaluate('()=>({sequence:__phase8.getSpeechSequence(),index:__phase8.getIndex(),status:__phase8.getState().status})');assert after['sequence']>before and after['index']==1 and after['status']=='running',after;return {'before':before,**after}
    def test_no_browser_page_errors():
        assert not errors,errors;return 'none'
    for name,fn in [
        ('No compatibility accessors remain',test_no_compatibility_accessors_or_accessor_declarations),
        ('Selectors and explicit actions replace legacy access',test_runtime_reads_use_selectors_and_writes_use_actions),
        ('Selectors/actions are authoritative and validated',test_selector_actions_are_authoritative_and_validated),
        ('Start/reveal/navigation/restart',test_start_reveal_next_previous_and_restart),
        ('Pause/resume timer behavior',test_pause_resume_timer_state),
        ('Stop/continue checkpoint restoration',test_stop_and_continue_restore_question),
        ('Completion and replay',test_completion_and_replay),
        ('Review subset behavior',test_review_starts_in_revision_mode_with_subset),
        ('Narration cancellation on navigation',test_navigation_invalidates_old_narration_sequence),
        ('No browser page errors',test_no_browser_page_errors),
    ]: check(name,fn)
    browser.close()
for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'SUMMARY: {sum(x[1]=="PASS" for x in results)}/{len(results)} passed')
if any(x[1]=='FAIL' for x in results): raise SystemExit(1)
