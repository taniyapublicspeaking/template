# Changelog

## v1.3.0-alpha9
- Fixed presentation-mode scrolling at all six tested viewport sizes by removing the desktop-only layout constraint.
- Kept long question, answer, and explanation content within a vertically scrollable presentation viewport.
- Kept Reveal Answer and Next controls visible/reachable through a sticky control row.
- Added short-height and mobile-specific layout adjustments, touch scrolling, wrapping, and safe-area padding.
- Re-ran the targeted six-viewport layout tests; see `TEST-REPORT.md`.
