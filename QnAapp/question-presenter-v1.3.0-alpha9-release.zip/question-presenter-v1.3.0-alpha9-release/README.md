# Question Presenter v1.3.0-alpha9

Standalone HTML/CSS/JavaScript question presentation app.

## This release
- Extends presentation-mode viewport management to desktop, tablet, mobile portrait, small mobile, and mobile landscape.
- Makes the presentation content viewport independently vertically scrollable with touch momentum scrolling.
- Keeps the teacher controls in a sticky bottom row inside the scrolling content area.
- Adds mobile safe-area padding and compact control/header sizing for short screens.
- Preserves the existing question engine and reducer-based state management.

## Files
- `question-presenter-v1.3.0-alpha9.html` — standalone application.
- `TEST-REPORT.md` — targeted presentation layout test report.
- `tests/` — existing regression suites and new targeted viewport results.

Open the HTML file in a modern browser. No framework or build step is required.
