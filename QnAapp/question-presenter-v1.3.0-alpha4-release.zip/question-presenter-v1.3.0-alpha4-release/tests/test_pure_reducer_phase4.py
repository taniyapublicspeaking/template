from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'question-presenter-v1.3.0-alpha4.html').read_text()
needle = '})();\n</script>'
assert needle in SRC
SRC = SRC.replace(needle, '''window.__reducerTest = {
    lessonReducer, getState: () => lessonState, dispatchLessonCommand, transitionLesson,
    captureAsyncContext, isAsyncContextCurrent, dispatchTimerAction, tick, TimerEngine,
    runQuestionDelay, scheduleSpeechDelay, scheduleLearningStage,
    setWaitingForTest: (value, ms=500) => { waitingBetweenQuestions=value; questionDelayRemaining=ms; },
    getRuntime: () => ({ i, timerGeneration, deadline, left, running, paused, phase, sessionId: lessonState.sessionId, questionSessionId: lessonState.questionSessionId }),
    forceTimerExpire: () => { deadline = Date.now() - 1; left = 0; tick(captureAsyncContext({ generation: timerGeneration })); }
};
})();
</script>''', 1)
HTML = Path('/tmp/question-presenter-v1.3.0-alpha4-phase4-test.html')
HTML.write_text(SRC)
results=[]
def check(name, fn):
    try: results.append((name, 'PASS', str(fn())))
    except Exception as e: results.append((name, 'FAIL', str(e)))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page()
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(HTML.read_text(), wait_until='domcontentloaded')

    def setup(mode='timed'):
        page.set_content(HTML.read_text(), wait_until='domcontentloaded')
        page.locator('#mode').select_option(mode)
        page.locator('#qSeconds').fill('5')
        page.locator('#questionDelay').fill('0')
        page.locator('#start').click()
        page.wait_for_selector('.question', timeout=3000)
        page.wait_for_function("() => window.__reducerTest.getState().status === 'running'", timeout=3000)

    def test_reducer_accepts_current_tick_rejects_stale_question_tick():
        r=page.evaluate('''() => {
          const {lessonReducer,getState}=window.__reducerTest; const base=getState();
          const s={...base,status:'running',sessionId:'s1',questionSessionId:4,timer:{...base.timer,status:'running',generation:9,remainingMs:1000}};
          const good=lessonReducer(s,{type:'TIMER/TICK',sessionId:'s1',questionSessionId:4,generation:9,remainingMs:500});
          const stale=lessonReducer(s,{type:'TIMER/TICK',sessionId:'s1',questionSessionId:3,generation:9,remainingMs:0});
          return {accepted:good.timer.remainingMs,rejected:stale===s,original:s.timer.remainingMs};
        }''')
        assert r=={'accepted':500,'rejected':True,'original':1000},r
        return r

    def test_reducer_rejects_stale_expiry_from_old_session():
        r=page.evaluate('''() => {const {lessonReducer,getState}=window.__reducerTest;const b=getState();const s={...b,status:'running',sessionId:'new-session',questionSessionId:2,timer:{...b.timer,status:'running',generation:12,remainingMs:100}};const n=lessonReducer(s,{type:'TIMER/EXPIRE',sessionId:'old-session',questionSessionId:2,generation:12,remainingMs:0});return {sameState:n===s,status:n.status,timer:n.timer.status,remaining:n.timer.remainingMs};}''')
        assert r=={'sameState':True,'status':'running','timer':'running','remaining':100},r
        return r

    def test_reducer_rejects_stale_timer_generation():
        r=page.evaluate('''() => {const {lessonReducer,getState}=window.__reducerTest;const b=getState();const s={...b,status:'running',sessionId:'s',questionSessionId:1,timer:{...b.timer,status:'running',generation:5,remainingMs:500}};const n=lessonReducer(s,{type:'TIMER/EXPIRE',sessionId:'s',questionSessionId:1,generation:4,remainingMs:0});return n===s;}''')
        assert r is True,r
        return 'Old generation cannot expire the active timer'

    def test_browser_timer_state_is_reducer_owned():
        setup('timed')
        r=page.evaluate('''() => {const s=window.__reducerTest.getState();return {status:s.status,timer:s.timer.status,ownerMatches:s.timer.ownerSessionId===s.sessionId&&s.timer.ownerQuestionSessionId===s.questionSessionId,generation:s.timer.generation>0};}''')
        assert r=={'status':'running','timer':'running','ownerMatches':True,'generation':True},r
        return r

    def test_stale_question_timer_cannot_change_question_or_timer():
        setup('timed')
        page.wait_for_timeout(120)
        ctx=page.evaluate('window.__reducerTest.captureAsyncContext({generation: window.__reducerTest.getRuntime().timerGeneration})')
        page.locator('#next').click()
        before=page.evaluate('''() => ({index:window.__reducerTest.getState().questionIndex,remaining:window.__reducerTest.getState().timer.remainingMs})''')
        page.evaluate('(ctx) => {const t=window.__reducerTest; t.tick(ctx)}',ctx)
        after=page.evaluate('''() => ({index:window.__reducerTest.getState().questionIndex,remaining:window.__reducerTest.getState().timer.remainingMs})''')
        assert after==before,{'before':before,'after':after}
        return after

    def test_old_session_context_is_invalid_after_new_lesson_starts():
        setup('teacher')
        old=page.evaluate('window.__reducerTest.captureAsyncContext()')
        page.locator('#stop').click()
        page.locator('#start').click()
        page.wait_for_function("() => window.__reducerTest.getState().status === 'running'", timeout=3000)
        r=page.evaluate('(ctx) => window.__reducerTest.isAsyncContextCurrent(ctx)',old)
        assert r is False,r
        return 'Old session callback context rejected after restart'

    def test_current_context_is_valid_only_for_current_question():
        setup('teacher')
        old=page.evaluate('window.__reducerTest.captureAsyncContext()')
        assert page.evaluate('(ctx) => window.__reducerTest.isAsyncContextCurrent(ctx)',old) is True
        page.locator('#next').click()
        r=page.evaluate('(ctx) => window.__reducerTest.isAsyncContextCurrent(ctx)',old)
        assert r is False,r
        return 'Question identity invalidates previous context'

    def test_timer_expiry_reveals_answer_once():
        setup('timed')
        page.evaluate('window.__reducerTest.forceTimerExpire()')
        r=page.evaluate('''() => {const s=window.__reducerTest.getState();return {phase:s.question.phase,answerVisible:s.question.answerVisible,status:s.status,timer:s.timer.status};}''')
        assert r=={'phase':'answer','answerVisible':True,'status':'running','timer':'idle'},r
        return r

    def test_navigation_replaces_timer_owner():
        setup('timed')
        before=page.evaluate('''() => {const s=window.__reducerTest.getState();return {q:s.timer.ownerQuestionSessionId,g:s.timer.generation};}''')
        page.locator('#next').click()
        after=page.evaluate('''() => {const s=window.__reducerTest.getState();return {q:s.timer.ownerQuestionSessionId,g:s.timer.generation,index:s.questionIndex};}''')
        assert after['index']==1 and after['q']==page.evaluate('window.__reducerTest.getState().questionSessionId') and after['g']>before['g'],{'before':before,'after':after}
        return {'before':before,'after':after}

    def test_stale_question_delay_callback_is_ignored():
        setup('teacher')
        page.evaluate('''() => {const t=window.__reducerTest;window.__fired=0;t.setWaitingForTest(true,500);const old=window.setTimeout;window.__capturedTimeout=null;window.setTimeout=(fn,ms)=>{window.__capturedTimeout=fn;return 987654;};try{t.runQuestionDelay();}finally{window.setTimeout=old;}}''')
        page.locator('#next').click()
        before=page.evaluate('window.__reducerTest.getState().questionIndex')
        page.evaluate('window.__capturedTimeout && window.__capturedTimeout()')
        after=page.evaluate('window.__reducerTest.getState().questionIndex')
        assert before==after==1,{'before':before,'after':after}
        return 'Cancelled question-delay callback cannot navigate again'

    def test_stale_speech_delay_callback_is_ignored():
        setup('teacher')
        page.evaluate('''() => {const t=window.__reducerTest;window.__fired=0;const old=window.setTimeout;window.__capturedTimeout=null;window.setTimeout=(fn,ms)=>{window.__capturedTimeout=fn;return 987655;};try{t.scheduleSpeechDelay(500,()=>window.__fired++);}finally{window.setTimeout=old;}}''')
        page.evaluate("window.__reducerTest.dispatchLessonCommand('NEXT_QUESTION')")
        page.evaluate('window.__capturedTimeout && window.__capturedTimeout()')
        r=page.evaluate('({fired:window.__fired, state:window.__reducerTest.getState().status, ctx:window.__reducerTest.getState().questionSessionId, cb:!!window.__capturedTimeout})')
        assert r['fired']==0,r
        return 'Speech-delay callback from the previous question is ignored'

    def test_stale_learning_stage_callback_is_ignored():
        setup('teacher')
        page.evaluate('''() => {const t=window.__reducerTest;window.__fired=0;const old=window.setTimeout;window.__capturedTimeout=null;window.setTimeout=(fn,ms)=>{window.__capturedTimeout=fn;return 987656;};try{t.scheduleLearningStage(500,()=>window.__fired++);}finally{window.setTimeout=old;}}''')
        page.evaluate("window.__reducerTest.dispatchLessonCommand('NEXT_QUESTION')")
        page.evaluate('window.__capturedTimeout && window.__capturedTimeout()')
        r=page.evaluate('({fired:window.__fired, state:window.__reducerTest.getState().status, ctx:window.__reducerTest.getState().questionSessionId, cb:!!window.__capturedTimeout})')
        assert r['fired']==0,r
        return 'Learning-stage callback from the previous question is ignored'

    def test_no_browser_page_errors():
        assert not errors,errors
        return 'none'

    check('Reducer accepts current timer tick and rejects stale question tick',test_reducer_accepts_current_tick_rejects_stale_question_tick)
    check('Reducer rejects expiry from an obsolete session',test_reducer_rejects_stale_expiry_from_old_session)
    check('Reducer rejects obsolete timer generations',test_reducer_rejects_stale_timer_generation)
    check('Browser timer ownership is reducer-managed',test_browser_timer_state_is_reducer_owned)
    check('Stale question timer cannot mutate current question or timer',test_stale_question_timer_cannot_change_question_or_timer)
    check('Old session context is invalid after a new lesson starts',test_old_session_context_is_invalid_after_new_lesson_starts)
    check('Question navigation invalidates prior async context',test_current_context_is_valid_only_for_current_question)
    check('Reducer accepts valid timer expiration exactly for its owner',test_timer_expiry_reveals_answer_once)
    check('Navigation assigns a new timer owner and generation',test_navigation_replaces_timer_owner)
    check('Stale question-delay callback is ignored',test_stale_question_delay_callback_is_ignored)
    check('Stale speech-delay callback is ignored',test_stale_speech_delay_callback_is_ignored)
    check('Stale learning-stage callback is ignored',test_stale_learning_stage_callback_is_ignored)
    check('No browser page errors',test_no_browser_page_errors)
    browser.close()

for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'SUMMARY: {sum(x[1]=="PASS" for x in results)}/{len(results)} passed')
if any(x[1]=='FAIL' for x in results): raise SystemExit(1)
