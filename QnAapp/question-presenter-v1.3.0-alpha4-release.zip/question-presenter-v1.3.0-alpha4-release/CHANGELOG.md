# Changelog

## v1.3.0-alpha4 — Pure Reducer Architecture, Phase 4

- Added reducer-validated `TIMER/TICK` and `TIMER/EXPIRE` actions.
- Timer state updates now flow through `lessonReducer` rather than direct timer-object assignment in the state synchronization path.
- Timer instances carry a generation plus owning lesson-session and question-session identifiers.
- Timer callbacks are ignored when their generation, lesson session, question session, or lifecycle status is obsolete.
- Question-delay, speech-delay, learning-stage, and speech-completion callbacks now validate captured session/question identity before performing work.
- Kept cancellation sequence tokens as an additional safeguard.
- Preserved Phases 1–3, CSV validation fixes, and the existing HTML interface.
- Added 13 focused Phase 4 regression checks for valid timer ticks/expiry, stale timer generations, obsolete sessions/questions, and stale question-delay, speech-delay, and learning-stage callbacks.
