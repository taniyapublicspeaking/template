# Question Presenter v1.3.0-alpha4

Standalone HTML/CSS/JavaScript question presenter. Open `question-presenter-v1.3.0-alpha4.html` in a modern browser. The application does not require a JavaScript framework.

## Phase 4 changes

Timer and asynchronous effects now capture ownership context for the lesson session and current question. Timer ticks and expiry must pass reducer checks for session ID, question-session ID, and timer generation. A callback from an earlier question/session cannot advance the current lesson or update the active timer. Question-delay, speech-delay, learning-stage, and speech completion callbacks also validate their captured context, alongside existing cancellation sequence tokens.

The reducer remains pure: it does not access the DOM, start timers, or call speech APIs. Runtime effects remain in the effect/compatibility layer. This is an incremental migration; not every legacy runtime variable has been removed yet.

## Regression tests

The `tests/` directory contains focused Playwright browser suites for Phases 1–4 and CSV validation. Tests use local Chromium at `/usr/bin/chromium` in the current build environment and can be run with Python and Playwright installed:

```bash
python tests/test_pure_reducer_phase1.py
python tests/test_pure_reducer_phase2.py
python tests/test_pure_reducer_phase3.py
python tests/test_pure_reducer_phase4.py
python tests/test_csv_validation.py
```

Phase 4's 13 checks cover reducer acceptance/rejection of current and stale timer events, timer ownership, obsolete session/question contexts, timer expiry, and stale question-delay, speech-delay, and learning-stage callbacks.
