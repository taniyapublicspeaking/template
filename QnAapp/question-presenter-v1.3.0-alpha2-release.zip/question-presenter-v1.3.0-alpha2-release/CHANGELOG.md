# Changelog — Question Presenter v1.3.0-alpha2

## Pure Reducer Architecture — Phase 2
- Added pure reducer actions for question navigation, restart, and reveal-answer state.
- `Next`, `Previous`, `Go to Question`, `Restart Question`, and `Reveal Answer` now pass through reducer-driven question state transitions.
- The reducer validates navigation indices, resets answer/explanation visibility on navigation/restart, advances the question-session sequence, and makes reveal idempotent.
- Kept timer, speech, and DOM updates in the effect/compatibility adapter rather than inside the reducer.
- Preserved CSV validation behaviour from v1.2.1 and the Phase 1 lifecycle reducer foundation.

## Scope and limitations
The app remains an incremental migration: timer/speech side effects, some runtime aliases, and other lifecycle commands have not yet been fully moved into reducer/effect separation. This alpha does not claim a complete reducer architecture.
