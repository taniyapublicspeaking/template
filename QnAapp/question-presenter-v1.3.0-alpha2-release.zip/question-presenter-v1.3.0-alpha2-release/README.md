# Question Presenter v1.3.0-alpha2

Standalone HTML application built with plain HTML, CSS, and JavaScript. No build step or framework is required.

## Phase 2 architecture
Question navigation and answer visibility now use pure reducer actions:
- `QUESTION/NAVIGATE` — validate target index, reset question/answer phase, advance question session ID.
- `QUESTION/RESTART` — retain the current index and reset the question to its initial phase.
- `QUESTION/REVEAL` — reveal the answer and switch phase; repeated reveal is a no-op.

The command/effect adapter still handles timers, speech cancellation/narration, and rendering after reducer state commits. This is an incremental migration, not a claim that the entire app is reducer-driven yet.

## Run
Open `question-presenter-v1.3.0-alpha2.html` in a modern browser.

## Regression tests
Requires Python Playwright and local Chromium at `/usr/bin/chromium`.

```bash
python tests/test_pure_reducer_phase1.py
python tests/test_pure_reducer_phase2.py
python tests/test_csv_validation.py
```
