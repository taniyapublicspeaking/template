# Question Presenter v1.3.0-alpha3

Standalone HTML application built with plain HTML, CSS, and JavaScript. No build step or framework is required.

## Phase 3 architecture

Lesson lifecycle decisions are reducer-driven:
- `LESSON/START` — accepts a new lesson only from idle, stopped, or completed.
- `LESSON/BEGIN` — moves a validated start into running state.
- `LESSON/PAUSE` and `LESSON/RESUME` — validate running/paused transitions and update timer state immutably.
- `LESSON/STOP` — stops the lesson and preserves its checkpoint.
- `LESSON/CONTINUE` — requires a stopped lesson with a checkpoint, then returns to running while leaving the checkpoint available for restoration.
- `LESSON/COMPLETE` — permits completion only when the lesson is active and the current question is the final question; it updates completion phase and timer state.
- `LESSON/CANCEL_START` and `LESSON/RESET` — handle cancellation/reset paths.

The command/effect adapter continues to perform timer operations, speech cancellation/narration, DOM rendering, and checkpoint restoration. This is an incremental migration; the legacy runtime aliases and a generic transition fallback remain for compatibility/reset paths.

## Run

Open `question-presenter-v1.3.0-alpha3.html` in a modern browser.

## Regression tests

Requires Python Playwright and local Chromium at `/usr/bin/chromium`.

```bash
python tests/test_pure_reducer_phase1.py
python tests/test_pure_reducer_phase2.py
python tests/test_pure_reducer_phase3.py
python tests/test_csv_validation.py
```
