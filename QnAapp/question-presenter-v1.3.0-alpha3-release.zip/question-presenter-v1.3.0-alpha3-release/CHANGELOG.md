# Changelog

## v1.3.0-alpha3 — Pure Reducer Architecture, Phase 3

- Added reducer actions for Start, Begin, Pause, Resume, Stop, Continue, Start cancellation, Reset, and Complete.
- Lifecycle transitions now validate the current state inside `lessonReducer`.
- Continue requires a saved checkpoint; checkpoint data remains available until the runtime has restored it.
- Completion is reducer-approved only when an active lesson is on its final question.
- Completion reducer state marks the question phase complete and the timer idle.
- Kept existing HTML/CSS interface, CSV validation fixes, question navigation reducer actions, and compatibility/effect adapters.
- Added reducer and browser regression tests for lifecycle actions and completion decisions.

## v1.3.0-alpha2

- Moved Next, Previous, Restart Question, Go to Question, and Reveal Answer into reducer-driven question state.
- Added Phase 2 reducer and browser regression tests.

## v1.3.0-alpha1

- Introduced the initial pure lesson reducer and lifecycle state foundation.
- Preserved CSV validation regression fixes.
