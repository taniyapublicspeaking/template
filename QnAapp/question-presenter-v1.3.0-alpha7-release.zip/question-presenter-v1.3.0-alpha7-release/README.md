# Question Presenter v1.3.0-alpha7

Standalone HTML/CSS/JavaScript question presenter. Open `question-presenter-v1.3.0-alpha7.html` in a modern browser; no build step or framework is required.

## Phase 7 — Reducer dispatch and architecture hardening

- Added a single `dispatchLessonAction(action)` commit boundary. It validates the action through `lessonReducer`, rejects no-op/invalid transitions, and is the only runtime location that assigns the authoritative `lessonState` object.
- Routed lesson, question, timer, and speech reducer commits through the dispatch boundary.
- Added explicit selectors for the authoritative lesson state, question bank, question index, mode, current question, phase, answer/explanation visibility, lifecycle status, timer, speech, and checkpoint.
- Adopted selectors in the current-question lookup, lifecycle checks, asynchronous callback context checks, and command gateway.
- Routed teacher controls and keyboard commands through `dispatchLessonCommand`.
- Added end-to-end coverage for all four learning modes, pause/resume, timer state, reveal/restart, navigation, completion, replay, review sessions, narration cancellation, invalid actions, and centralized dispatch.
- Preserved Phases 1–6 and CSV validation behavior.

## Known migration boundary

A small set of reducer-backed property accessors (`list`, `i`, `mode`, `phase`, `revealed`, `explanationVisible`, `running`, and `paused`) remains for legacy rendering/effect paths. They no longer provide a second independent source of truth, but full replacement of every accessor with direct selector/action calls remains a follow-up migration task. This release therefore hardens the central commit boundary without claiming that every legacy property-style reference has been eliminated.

## Tests

See `TEST-REPORT.md`. Tests use Playwright with local Chromium. Browser speech tests validate callback and state sequencing with controlled speech mocks; they do not certify audible pronunciation on every device.
