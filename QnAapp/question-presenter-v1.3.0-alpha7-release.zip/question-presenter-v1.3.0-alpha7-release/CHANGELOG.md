# Changelog

## v1.3.0-alpha7 — Phase 7: Reducer dispatch and architecture hardening

- Centralized reducer state commits through `dispatchLessonAction`.
- Routed lesson, question, timer, and speech state commits through the dispatch boundary.
- Added explicit state selectors and used them in core question lookup, lifecycle checks, async context validation, and command handling.
- Verified the primary teacher toolbar and keyboard actions use `dispatchLessonCommand`.
- Added 16 Phase 7 end-to-end regression tests across learning modes, pause/resume, timers, narration cancellation, navigation, completion, replay, and review.
- Re-ran the previous Phase 1–6 and CSV validation suites.

## v1.3.0-alpha6

- Made reducer state authoritative for core lesson fields and removed the generic lifecycle fallback.
