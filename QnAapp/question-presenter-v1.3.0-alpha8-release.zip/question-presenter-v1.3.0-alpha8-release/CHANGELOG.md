# Changelog

## v1.3.0-alpha8 — Final compatibility-removal pass

- Removed global property accessors used to emulate legacy lesson state variables.
- Migrated runtime reads to explicit reducer-state selectors.
- Migrated writes to explicit reducer-backed action helpers.
- Updated timer and narration regression hooks to use selectors rather than removed globals.
- Reworked Phase 6 tests to validate explicit actions and the absence of compatibility accessors.
- Added 10 Phase 8 regression tests covering accessor removal, selectors/actions, navigation, pause/resume, stop/continue, completion, replay, review, and narration cancellation.
- Re-ran all nine regression suites: 103/103 checks passed.

## v1.3.0-alpha7 — Phase 7: Architecture hardening

- Centralized reducer commits and expanded end-to-end learning-mode and completion tests.
