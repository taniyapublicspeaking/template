from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'question-presenter-v1.3.0-alpha8.html').read_text()
needle = '})();\n</script>'
assert needle in SRC
SRC = SRC.replace(needle, '''window.__phase6 = {
  lessonReducer, getState:()=>selectLessonState(), applyLessonAction, syncEffectState,
  transitionLesson, start, pause, next, go, reveal, stop, resume, finish,
  getQuestion:()=>selectQuestion(), getQuestions:()=>selectQuestions(),
  getIndex:()=>selectQuestionIndex(), getMode:()=>selectMode(),
  getPhase:()=>selectQuestionPhase(), isRunning:()=>selectIsRunning(), isPaused:()=>selectIsPaused(),
  replaceQuestions, setQuestionIndex, setLearningMode, setQuestionPhase, setAnswerVisible, setExplanationVisible
};
})();
</script>''', 1)
HTML = Path('/tmp/question-presenter-v1.3.0-alpha8-phase6-test.html')
HTML.write_text(SRC)
results=[]
def check(name, fn):
    try: results.append((name, 'PASS', str(fn())))
    except Exception as e: results.append((name, 'FAIL', str(e)))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page(); errors=[]; page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(HTML.read_text(), wait_until='domcontentloaded')
    def test_source_has_no_duplicated_core_let_bindings():
        assert 'Object.defineProperties(globalThis' not in SRC
        assert 'syncLessonState' not in SRC and 'case "LESSON/TRANSITION"' not in SRC
        for name in ['list','i','phase','revealed','explanationVisible','running','paused']:
            assert not __import__('re').search(r'\b'+name+r'\s*:\s*\{\s*configurable', SRC), name
        for direct_write in ['lessonState.sessionId=', 'lessonState.questionSessionId++;', 'lessonState.timing.pausedAt=', 'lessonState.checkpoint.snapshot=', 'lessonState.error=']:
            assert direct_write not in SRC, direct_write
        return 'Core state is reducer-owned and no compatibility accessors are declared'
    def test_question_bank_action_updates_authoritative_state():
        r=page.evaluate('''() => {const t=window.__phase6,q=[{question:'A'},{question:'B'}];t.replaceQuestions(q);const s=t.getState();return {sameArray:s.questions===q,copyLength:s.questions.length,index:s.questionIndex,qid:s.questionSessionId,phase:s.question.phase};}''')
        assert r=={'sameArray':False,'copyLength':2,'index':0,'qid':1,'phase':'question'},r; return r
    def test_index_action_uses_reducer_validation():
        r=page.evaluate('''() => {const t=window.__phase6;t.replaceQuestions([{question:'A'},{question:'B'}]);t.setQuestionIndex(1);const good=t.getIndex();t.setQuestionIndex(99);return {good,after:t.getIndex()};}''')
        assert r=={'good':1,'after':1},r; return r
    def test_mode_action_updates_reducer_state():
        r=page.evaluate('''() => {const t=window.__phase6;t.setLearningMode('teacher');const accepted=t.getMode();t.setLearningMode('not-a-mode');return {accepted,rejected:t.getMode()};}''')
        assert r=={'accepted':'teacher','rejected':'teacher'},r; return r
    def test_phase_and_visibility_actions_update_reducer_state():
        r=page.evaluate('''() => {const t=window.__phase6;t.setQuestionPhase('answer');t.setAnswerVisible(true);t.setExplanationVisible(true);return t.getState().question;}''')
        assert r=={'phase':'answer','answerVisible':True,'explanationVisible':True},r; return r
    def test_legacy_global_accessors_are_absent():
        r=page.evaluate('''() => ['list','i','phase','revealed','explanationVisible','running','paused'].map(k=>({key:k,exists:k in window,accessor:!!(Object.getOwnPropertyDescriptor(window,k)?.get||Object.getOwnPropertyDescriptor(window,k)?.set)}))''')
        assert all(not x['exists'] and not x['accessor'] for x in r),r; return r
    def test_generic_transition_compatibility_action_removed():
        case_removed='case "LESSON/TRANSITION"' not in SRC
        r=page.evaluate('''() => {const t=window.__phase6,s=t.getState();return {actionNoop:t.lessonReducer(s,{type:'LESSON/TRANSITION',status:'starting'})===s};}''')
        assert case_removed and r=={'actionNoop':True},(case_removed,r); return {'caseRemoved':case_removed,**r}
    def test_sync_only_updates_effect_observations():
        r=page.evaluate('''() => {const t=window.__phase6;t.replaceQuestions([{question:'One'},{question:'Two'}]);t.setQuestionIndex(1);t.setLearningMode('self');t.setQuestionPhase('answer');t.setAnswerVisible(true);const before=t.getState();t.syncEffectState();const after=t.getState();return {index:after.questionIndex,mode:after.mode,phase:after.question.phase,visible:after.question.answerVisible,questions:after.questions.length,identityChanged:after!==before};}''')
        assert r=={'index':1,'mode':'self','phase':'answer','visible':True,'questions':2,'identityChanged':True},r; return r
    def test_browser_start_reveal_next_preserves_ui_and_state():
        page.set_content(HTML.read_text(), wait_until='domcontentloaded');page.locator('#start').click();assert page.locator('.question').inner_text(timeout=3000);page.locator('#reveal').click();assert page.locator('.answer').count()==1
        a=page.evaluate('''() => ({index:window.__phase6.getIndex(),phase:window.__phase6.getPhase(),visible:window.__phase6.getState().question.answerVisible})''');page.locator('#next').click();b=page.evaluate('''() => ({index:window.__phase6.getIndex(),phase:window.__phase6.getPhase(),visible:window.__phase6.getState().question.answerVisible})''')
        assert a=={'index':0,'phase':'answer','visible':True} and b=={'index':1,'phase':'question','visible':False},(a,b);return {'revealed':a,'next':b}
    def test_pause_stop_continue_lifecycle_without_runtime_copies():
        page.set_content(HTML.read_text(), wait_until='domcontentloaded');page.locator('#start').click();page.locator('#next').click();page.locator('#pause').click()
        paused=page.evaluate('''() => ({status:window.__phase6.getState().status,running:window.__phase6.isRunning(),paused:window.__phase6.isPaused()})''');page.locator('#stop').click();stopped=page.evaluate('''() => ({status:window.__phase6.getState().status,running:window.__phase6.isRunning(),paused:window.__phase6.isPaused(),checkpoint:window.__phase6.getState().checkpoint.available})''');page.locator('#resume').click();resumed=page.evaluate('''() => ({status:window.__phase6.getState().status,running:window.__phase6.isRunning(),paused:window.__phase6.isPaused(),index:window.__phase6.getIndex()})''')
        assert paused=={'status':'paused','running':True,'paused':True},paused;assert stopped=={'status':'stopped','running':False,'paused':False,'checkpoint':True},stopped;assert resumed=={'status':'running','running':True,'paused':False,'index':1},resumed;return {'paused':paused,'stopped':stopped,'resumed':resumed}
    def test_reducer_state_is_not_overwritten_by_effect_sync():
        r=page.evaluate('''() => {const t=window.__phase6;t.replaceQuestions([{question:'X'},{question:'Y'}]);t.setQuestionIndex(1);t.setLearningMode('teacher');t.setAnswerVisible(true);const state=t.getState();t.syncEffectState();return {sameCore:state.questions===t.getState().questions && state.questionIndex===t.getState().questionIndex && state.mode===t.getState().mode && state.question.answerVisible===t.getState().question.answerVisible};}''')
        assert r['sameCore'] is True,r;return 'Effect synchronization does not overwrite reducer-owned core fields'
    check('No duplicated core bindings or compatibility accessors',test_source_has_no_duplicated_core_let_bindings)
    check('Question bank action updates authoritative state',test_question_bank_action_updates_authoritative_state)
    check('Index action validates through reducer',test_index_action_uses_reducer_validation)
    check('Mode action updates reducer state',test_mode_action_updates_reducer_state)
    check('Phase and visibility actions update reducer state',test_phase_and_visibility_actions_update_reducer_state)
    check('Legacy global accessors are absent',test_legacy_global_accessors_are_absent)
    check('Generic lifecycle compatibility action is removed',test_generic_transition_compatibility_action_removed)
    check('Sync updates only effect observations',test_sync_only_updates_effect_observations)
    check('Start/reveal/next browser behavior preserved',test_browser_start_reveal_next_preserves_ui_and_state)
    check('Pause/stop/continue behavior preserved',test_pause_stop_continue_lifecycle_without_runtime_copies)
    check('Effect synchronization cannot overwrite core fields',test_reducer_state_is_not_overwritten_by_effect_sync)
    check('No browser page errors',lambda: (errors if not errors else (_ for _ in ()).throw(AssertionError(errors))) or 'none')
    browser.close()
for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'SUMMARY: {sum(x[1]=="PASS" for x in results)}/{len(results)} passed')
if any(x[1]=='FAIL' for x in results): raise SystemExit(1)
