from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'question-presenter-v1.3.0-alpha8.html').read_text()
needle = '})();\n</script>'
assert needle in SRC
HOOK = '''window.__phase7 = {
  getState:()=>selectLessonState(), getQuestions:()=>selectQuestions(),
  getIndex:()=>selectQuestionIndex(), getMode:()=>selectMode(),
  getQuestion:()=>selectQuestion(), getPhase:()=>selectQuestionPhase(),
  isRunning:()=>selectIsRunning(), isPaused:()=>selectIsPaused(),
  getTimer:()=>selectTimerState(), getSpeech:()=>selectSpeechState(),
  dispatch:dispatchLessonAction, command:dispatchLessonCommand,
  start, pause, next, go, reveal, stop, resume, finish, repeatCompletedLesson,
  beginReviewSession, SpeechEffects, getSpeechSequence:()=>speechSequence
};
})();
</script>'''
HTML = Path('/tmp/tester-phase7-test.html')
HTML.write_text(SRC.replace(needle, HOOK, 1))
results=[]
def check(name, fn):
    try: results.append((name, 'PASS', str(fn())))
    except Exception as e: results.append((name, 'FAIL', str(e)))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page()
    errors=[]; page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(HTML.read_text(), wait_until='domcontentloaded')

    def reset():
        page.set_content(HTML.read_text(), wait_until='domcontentloaded')

    def test_single_state_commit_boundary():
        script=SRC.split('<script>',1)[1].split('</script>',1)[0]
        writes=list(re.finditer(r'\blessonState\s*=',script))
        assert len(writes)==2, [(script[m.start()-40:m.end()+30]) for m in writes] # initial declaration + dispatch commit
        boundary=script.index('function dispatchLessonAction(')
        apply=script.index('function applyLessonAction(', boundary)
        assert boundary < writes[1].start() < apply, script[writes[1].start()-100:writes[1].end()+80]
        assert 'lessonState = next;' in script[writes[1].start()-30:writes[1].end()+50]
        return 'Only the initial declaration and dispatch boundary assign lessonState'

    def test_selectors_reflect_reducer_state():
        r=page.evaluate('''()=>{const t=window.__phase7; t.dispatch({type:'SESSION/SET_QUESTIONS',questions:[{question:'A',answer:'a'},{question:'B',answer:'b'}]});t.dispatch({type:'SESSION/SET_MODE',mode:'teacher'});t.dispatch({type:'QUESTION/SET_INDEX',index:1});return {questions:t.getQuestions().length,index:t.getIndex(),mode:t.getMode(),question:t.getQuestion().question,phase:t.getPhase()}}''')
        assert r=={'questions':2,'index':1,'mode':'teacher','question':'B','phase':'question'},r
        return r

    def test_invalid_action_is_noop_at_dispatch_boundary():
        r=page.evaluate('''()=>{const t=window.__phase7,before=t.getState(),result=t.dispatch({type:'UNKNOWN/ACTION'});return {accepted:result.accepted,same:before===t.getState()}}''')
        assert r=={'accepted':False,'same':True},r; return r

    def test_all_learning_modes_start_with_authoritative_mode():
        modes=['timed','teacher','self','revision']; observed=[]
        for mode in modes:
            reset(); page.locator('#mode').select_option(mode); page.locator('#start').click()
            observed.append(page.evaluate('''()=>({mode:window.__phase7.getMode(),status:window.__phase7.getState().status,index:window.__phase7.getIndex()})'''))
        assert [x['mode'] for x in observed]==modes,observed
        assert all(x['status']=='running' for x in observed),observed
        return observed

    def test_pause_resume_keeps_question_and_reducer_status_consistent():
        reset(); page.locator('#start').click(); page.locator('#next').click(); page.locator('#pause').click()
        paused=page.evaluate('''()=>({status:window.__phase7.getState().status,paused:window.__phase7.isPaused(),index:window.__phase7.getIndex()})''')
        page.locator('#pause').click()
        resumed=page.evaluate('''()=>({status:window.__phase7.getState().status,paused:window.__phase7.isPaused(),index:window.__phase7.getIndex()})''')
        assert paused=={'status':'paused','paused':True,'index':1},paused
        assert resumed=={'status':'running','paused':False,'index':1},resumed
        return {'paused':paused,'resumed':resumed}

    def test_next_previous_navigation_uses_reducer_index():
        reset(); page.locator('#start').click(); page.locator('#next').click(); page.locator('#prev').click()
        r=page.evaluate('''()=>({index:window.__phase7.getIndex(),question:window.__phase7.getQuestion().question,phase:window.__phase7.getPhase()})''')
        assert r['index']==0 and r['phase']=='question',r
        return r

    def test_reveal_and_restart_question_clear_visibility():
        reset(); page.locator('#start').click(); page.locator('#reveal').click()
        a=page.evaluate('''()=>({phase:window.__phase7.getPhase(),visible:window.__phase7.getState().question.answerVisible})''')
        page.locator('#restartQ').click()
        b=page.evaluate('''()=>({phase:window.__phase7.getPhase(),visible:window.__phase7.getState().question.answerVisible,index:window.__phase7.getIndex()})''')
        assert a=={'phase':'answer','visible':True},a
        assert b=={'phase':'question','visible':False,'index':0},b
        return {'revealed':a,'restarted':b}

    def test_timer_pause_resume_state_is_reducer_backed():
        reset(); page.locator('#start').click()
        page.locator('#pause').click()
        paused=page.evaluate('''()=>({lesson:window.__phase7.getState().status,timer:window.__phase7.getTimer().status})''')
        page.locator('#pause').click()
        resumed=page.evaluate('''()=>({lesson:window.__phase7.getState().status,timer:window.__phase7.getTimer().status})''')
        assert paused['lesson']=='paused' and paused['timer'] in ('paused','idle'),paused
        assert resumed['lesson']=='running' and resumed['timer'] in ('running','idle'),resumed
        return {'paused':paused,'resumed':resumed}

    def test_completion_screen_and_completed_state():
        reset(); page.locator('#start').click()
        page.evaluate('''()=>{window.__phase7.dispatch({type:'QUESTION/SET_INDEX',index:5})}''')
        page.locator('#next').click()
        r=page.evaluate('''()=>({status:window.__phase7.getState().status,phase:window.__phase7.getPhase(),done:!document.querySelector('#done').classList.contains('hidden')})''')
        assert r=={'status':'completed','phase':'complete','done':True},r
        return r

    def test_repeat_completed_lesson_returns_to_first_question():
        reset(); page.locator('#start').click(); page.evaluate('''()=>window.__phase7.dispatch({type:'QUESTION/SET_INDEX',index:5})'''); page.locator('#next').click(); page.locator('#again').click()
        r=page.evaluate('''()=>({status:window.__phase7.getState().status,index:window.__phase7.getIndex(),phase:window.__phase7.getPhase(),done:!document.querySelector('#done').classList.contains('hidden')})''')
        assert r['status']=='running' and r['index']==0 and r['phase']=='question' and not r['done'],r
        return r

    def test_review_flow_uses_revision_mode_and_starts_at_first_review_question():
        reset(); page.locator('#start').click(); page.evaluate('''()=>window.__phase7.dispatch({type:'QUESTION/SET_INDEX',index:5})'''); page.locator('#next').click(); page.locator('#reviewAll').click()
        r=page.evaluate('''()=>({status:window.__phase7.getState().status,mode:window.__phase7.getMode(),index:window.__phase7.getIndex(),count:window.__phase7.getQuestions().length})''')
        assert r['status']=='running' and r['mode']=='revision' and r['index']==0 and r['count']>=1,r
        return r

    def test_review_subset_preserves_question_identity():
        reset(); page.locator('#start').click(); page.evaluate('''()=>{window.__phase7.dispatch({type:'QUESTION/SET_INDEX',index:5});window.__phase7.dispatch({type:'QUESTION/SET_VISIBILITY',answerVisible:true,explanationVisible:false})}'''); page.locator('#next').click()
        # Exercise review entry directly with a known subset, independent of confidence UI.
        r=page.evaluate('''()=>{const t=window.__phase7, subset=t.getQuestions().slice(1,3);t.beginReviewSession(subset,'Focused review test');return {mode:t.getMode(),index:t.getIndex(),count:t.getQuestions().length,first:t.getQuestion().question}}''')
        assert r['mode']=='revision' and r['index']==0 and r['count']==2,r
        return r

    def test_narration_cancel_invalidates_obsolete_callbacks():
        reset(); page.locator('#qVoice').check(); page.locator('#start').click()
        before=page.evaluate('''()=>window.__phase7.getSpeechSequence()''')
        page.locator('#next').click()
        after=page.evaluate('''()=>({sequence:window.__phase7.getSpeechSequence(),index:window.__phase7.getIndex(),status:window.__phase7.getState().status})''')
        assert after['sequence']>before and after['index']==1 and after['status']=='running',after
        return {'before':before,**after}

    def test_state_changing_ui_commands_use_command_gateway():
        for required in ["dispatchLessonCommand('PREVIOUS_QUESTION')", "dispatchLessonCommand('NEXT_QUESTION')", "dispatchLessonCommand('REVEAL_ANSWER')", "dispatchLessonCommand('PAUSE_TOGGLE')", "dispatchLessonCommand('STOP')"]:
            assert required in SRC, required
        return 'Primary teacher controls and keyboard shortcuts route through dispatchLessonCommand'

    def test_direct_reducer_commits_are_centralized():
        script=SRC.split('<script>',1)[1].split('</script>',1)[0]
        # Reducer is called directly only inside the central dispatch boundary and read-only completion/test logic is absent.
        calls=[m.start() for m in re.finditer(r'lessonReducer\(',script)]
        assert len(calls)==2, len(calls) # declaration + dispatch boundary
        return 'Reducer invocations are centralized in the dispatch boundary'

    def test_no_browser_page_errors():
        assert not errors, errors
        return 'none'

    checks=[
      ('Single state commit boundary',test_single_state_commit_boundary),
      ('Explicit selectors reflect reducer state',test_selectors_reflect_reducer_state),
      ('Invalid action rejected by dispatch boundary',test_invalid_action_is_noop_at_dispatch_boundary),
      ('All four learning modes start correctly',test_all_learning_modes_start_with_authoritative_mode),
      ('Pause/resume preserves question and status',test_pause_resume_keeps_question_and_reducer_status_consistent),
      ('Next/previous use reducer index',test_next_previous_navigation_uses_reducer_index),
      ('Reveal/restart clears visibility',test_reveal_and_restart_question_clear_visibility),
      ('Timer pause/resume state',test_timer_pause_resume_state_is_reducer_backed),
      ('Completion screen and completed state',test_completion_screen_and_completed_state),
      ('Replay returns to first question',test_repeat_completed_lesson_returns_to_first_question),
      ('Review flow starts in revision mode',test_review_flow_uses_revision_mode_and_starts_at_first_review_question),
      ('Review subset starts at first selected question',test_review_subset_preserves_question_identity),
      ('Narration cancellation invalidates old callbacks',test_narration_cancel_invalidates_obsolete_callbacks),
      ('UI commands use central command gateway',test_state_changing_ui_commands_use_command_gateway),
      ('Reducer calls centralized',test_direct_reducer_commits_are_centralized),
      ('No browser page errors',test_no_browser_page_errors),
    ]
    for name,fn in checks: check(name,fn)
    browser.close()
for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'SUMMARY: {sum(x[1]=="PASS" for x in results)}/{len(results)} passed')
if any(x[1]=='FAIL' for x in results): raise SystemExit(1)
