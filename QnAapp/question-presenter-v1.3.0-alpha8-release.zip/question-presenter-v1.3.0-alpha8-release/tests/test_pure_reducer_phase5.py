from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'question-presenter-v1.3.0-alpha8.html').read_text()
needle = '})();\n</script>'
assert needle in SRC
SRC = SRC.replace(needle, '''window.__phase5 = {
  lessonReducer, getState:()=>lessonState, dispatchSpeechState, SpeechEffects,
  start, pause, next, go, reveal, say, speakAnswerExplanation, speakStageText,
  getSpeechSequence:()=>speechSequence,
  getCurrentQuestion:()=>cur(),
  getRuntime:()=>({status:lessonState.status, index:selectQuestionIndex(), paused:selectIsPaused(), sessionId:lessonState.sessionId, questionSessionId:lessonState.questionSessionId, speechSequence})
};
})();
</script>''', 1)
HTML = Path('/tmp/tester-phase5-test.html')
HTML.write_text(SRC)
results=[]
def check(name, fn):
    try: results.append((name, 'PASS', str(fn())))
    except Exception as e: results.append((name, 'FAIL', str(e)))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page()
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    def setup(mode='teacher'):
        page.set_content(HTML.read_text(), wait_until='domcontentloaded')
        page.evaluate('''() => {
          const t=window.__phase5; window.__utterances=[]; window.__speechCancelCount=0;
          t.SpeechEffects.speakUtterance=(u)=>window.__utterances.push(u);
          try{window.speechSynthesis.cancel=()=>{window.__speechCancelCount++};window.speechSynthesis.pause=()=>{};window.speechSynthesis.resume=()=>{};}catch(e){}
          document.querySelector('#mode').value=arguments[0]||'teacher';
          document.querySelector('#qVoice').checked=false;document.querySelector('#aVoice').checked=false;
          t.start();
        }'''.replace("arguments[0]||'teacher'", repr(mode)))
        page.wait_for_function("() => window.__phase5.getState().status === 'running'", timeout=3000)
    def test_reducer_accepts_current_speech_start_and_end():
        r=page.evaluate('''() => {const t=window.__phase5,b=t.getState();let s={...b,status:'running',sessionId:'s',questionSessionId:4,speech:{status:'idle',type:null,sequenceId:8}};const a=t.lessonReducer(s,{type:'SPEECH/START',sessionId:'s',questionSessionId:4,sequenceId:9,speechType:'question'});const e=t.lessonReducer(a,{type:'SPEECH/END',sessionId:'s',questionSessionId:4,sequenceId:9});return {start:a.speech,end:e.speech,original:s.speech};}''')
        assert r['start']=={'status':'speaking','type':'question','sequenceId':9} and r['end']=={'status':'idle','type':None,'sequenceId':9} and r['original']['sequenceId']==8,r
        return r
    def test_reducer_rejects_obsolete_session_event():
        r=page.evaluate('''() => {const t=window.__phase5,b=t.getState(),s={...b,status:'running',sessionId:'new',questionSessionId:1,speech:{status:'speaking',type:'answer',sequenceId:3}};return t.lessonReducer(s,{type:'SPEECH/END',sessionId:'old',questionSessionId:1,sequenceId:3})===s}''')
        assert r is True; return 'Old lesson speech event rejected'
    def test_reducer_rejects_obsolete_question_event():
        r=page.evaluate('''() => {const t=window.__phase5,b=t.getState(),s={...b,status:'running',sessionId:'s',questionSessionId:5,speech:{status:'speaking',type:'answer',sequenceId:3}};return t.lessonReducer(s,{type:'SPEECH/ERROR',sessionId:'s',questionSessionId:4,sequenceId:3,error:'SPEECH_ERROR'})===s}''')
        assert r is True; return 'Previous-question speech error rejected'
    def test_reducer_rejects_old_sequence_end():
        r=page.evaluate('''() => {const t=window.__phase5,b=t.getState(),s={...b,status:'running',sessionId:'s',questionSessionId:1,speech:{status:'speaking',type:'question',sequenceId:7}};return t.lessonReducer(s,{type:'SPEECH/END',sessionId:'s',questionSessionId:1,sequenceId:6})===s}''')
        assert r is True; return 'Older utterance completion rejected'
    def test_reducer_cancel_invalidates_active_sequence():
        r=page.evaluate('''() => {const t=window.__phase5,b=t.getState(),s={...b,sessionId:'s',questionSessionId:1,speech:{status:'speaking',type:'question',sequenceId:4}};const n=t.lessonReducer(s,{type:'SPEECH/CANCEL',sessionId:'s',questionSessionId:1,sequenceId:5});return n.speech}''')
        assert r=={'status':'idle','type':None,'sequenceId':5},r; return r
    def test_say_routes_state_through_reducer():
        setup(); page.evaluate("window.__phase5.SpeechEffects.say('Question narration')")
        r=page.evaluate("({speech:window.__phase5.getState().speech,count:window.__utterances.length,text:window.__utterances[0]?.text})")
        assert r['speech']['status']=='speaking' and r['speech']['type']=='question' and r['count']==1 and r['text']=='Question narration',r
        return r
    def test_utterance_end_returns_reducer_state_to_idle():
        setup(); page.evaluate("window.__phase5.SpeechEffects.say('Hello')"); page.evaluate('window.__utterances[0].onend()')
        r=page.evaluate('window.__phase5.getState().speech')
        assert r['status']=='idle' and r['type'] is None,r; return r
    def test_navigation_makes_old_utterance_end_inert():
        setup(); page.evaluate("window.__phase5.SpeechEffects.say('Old question')"); page.evaluate('window.__phase5.next()')
        before=page.evaluate('JSON.stringify(window.__phase5.getState().speech)'); page.evaluate('window.__utterances[0].onend()')
        after=page.evaluate('JSON.stringify(window.__phase5.getState().speech)')
        assert before==after,(before,after); return 'Late onend cannot mutate next question state'
    def test_navigation_makes_old_utterance_error_inert():
        setup(); page.evaluate("window.__phase5.SpeechEffects.say('Old question')"); page.evaluate('window.__phase5.next()')
        before=page.evaluate('window.__phase5.getState().error'); page.evaluate("window.__utterances[0].onerror({error:'synthesis-failed'})")
        after=page.evaluate('window.__phase5.getState().error')
        assert before==after,(before,after); return 'Late onerror cannot set an error for the new question'
    def test_cancel_increments_sequence_and_cancels_browser_speech():
        setup(); page.evaluate("window.__phase5.SpeechEffects.say('Cancel me')"); before=page.evaluate('window.__phase5.getSpeechSequence()')
        page.evaluate('window.__phase5.SpeechEffects.cancel()')
        r=page.evaluate('({sequence:window.__phase5.getSpeechSequence(),count:window.__speechCancelCount,state:window.__phase5.getState().speech})')
        assert r['sequence']==before+1 and r['count']>=1 and r['state']['status']=='idle',r; return r
    def test_cancelled_utterance_completion_is_inert():
        setup(); page.evaluate("window.__phase5.SpeechEffects.say('Cancel me')"); page.evaluate('window.__phase5.SpeechEffects.cancel()')
        before=page.evaluate('JSON.stringify(window.__phase5.getState().speech)'); page.evaluate('window.__utterances[0].onend()')
        after=page.evaluate('JSON.stringify(window.__phase5.getState().speech)')
        assert before==after,(before,after); return 'Canceled utterance callback ignored'
    def test_pause_resume_uses_reducer_speech_transitions():
        setup(); page.evaluate("window.__phase5.SpeechEffects.say('Pause me')"); page.evaluate('window.__phase5.pause()')
        paused=page.evaluate('window.__phase5.getState().speech.status')
        page.evaluate('window.__phase5.pause()')
        resumed=page.evaluate('window.__phase5.getState().speech.status')
        assert paused=='paused' and resumed=='speaking',{'paused':paused,'resumed':resumed}; return {'paused':paused,'resumed':resumed}
    def test_answer_then_explanation_narration_order():
        setup(); page.locator('#explanationDelay').fill('0'); page.evaluate("window.__phase5.SpeechEffects.speakAnswerExplanation()")
        first=page.evaluate('window.__utterances[0]?.text'); page.evaluate('window.__utterances[0].onend()')
        page.wait_for_timeout(30)
        r=page.evaluate('window.__utterances.map(u=>u.text)')
        assert first=='Living things need air, water, food, and suitable conditions.' and len(r)>=2 and 'These needs help living things' in r[1],r
        return r[:2]
    def test_stale_explanation_delay_after_navigation_is_inert():
        setup(); page.locator('#explanationDelay').fill('1')
        page.evaluate("window.__phase5.SpeechEffects.speakAnswerExplanation()")
        page.evaluate('window.__utterances[0].onend()')
        page.evaluate('window.__phase5.next()')
        page.wait_for_timeout(1100)
        r=page.evaluate('window.__utterances.map(u=>u.text)')
        assert len(r)==1,r; return 'Delayed explanation is not spoken after question navigation'
    def test_no_browser_page_errors():
        assert not errors,errors; return 'none'
    tests=[
      ('Reducer accepts current speech start/end',test_reducer_accepts_current_speech_start_and_end),
      ('Reducer rejects obsolete session event',test_reducer_rejects_obsolete_session_event),
      ('Reducer rejects obsolete question event',test_reducer_rejects_obsolete_question_event),
      ('Reducer rejects old sequence completion',test_reducer_rejects_old_sequence_end),
      ('Reducer cancellation invalidates sequence',test_reducer_cancel_invalidates_active_sequence),
      ('Speech effect updates reducer state',test_say_routes_state_through_reducer),
      ('Utterance completion clears reducer speech state',test_utterance_end_returns_reducer_state_to_idle),
      ('Obsolete onend is ignored after navigation',test_navigation_makes_old_utterance_end_inert),
      ('Obsolete onerror is ignored after navigation',test_navigation_makes_old_utterance_error_inert),
      ('Cancellation increments sequence and cancels',test_cancel_increments_sequence_and_cancels_browser_speech),
      ('Canceled utterance completion is ignored',test_cancelled_utterance_completion_is_inert),
      ('Pause/resume uses reducer speech transitions',test_pause_resume_uses_reducer_speech_transitions),
      ('Answer then explanation narration order',test_answer_then_explanation_narration_order),
      ('Stale delayed explanation is ignored',test_stale_explanation_delay_after_navigation_is_inert),
      ('No browser page errors',test_no_browser_page_errors)]
    for name,fn in tests:
        if name!='No browser page errors':
            try: setup('teacher' if 'Pause/resume' not in name else 'timed')
            except Exception as e: results.append((name,'FAIL','setup: '+str(e))); continue
        check(name,fn)
    browser.close()

for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'RESULT: {sum(s=="PASS" for _,s,_ in results)}/{len(results)} passed')
if any(s!='PASS' for _,s,_ in results): raise SystemExit(1)
