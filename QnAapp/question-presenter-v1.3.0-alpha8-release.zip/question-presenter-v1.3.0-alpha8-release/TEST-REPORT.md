# Test Report — Question Presenter v1.3.0-alpha8

**Environment:** Playwright + local Chromium (`/usr/bin/chromium`), Python 3.13, Node.js syntax check.

## Full regression results

| Suite | Passed | Total |
|---|---:|---:|
| Pure reducer Phase 1 | 6 | 6 |
| Pure reducer Phase 2 | 10 | 10 |
| Pure reducer Phase 3 | 10 | 10 |
| Pure reducer Phase 4 — timer ownership and stale callbacks | 13 | 13 |
| Pure reducer Phase 5 — speech and narration | 15 | 15 |
| Pure reducer Phase 6 — reducer-authoritative state | 12 | 12 |
| Pure reducer Phase 7 — end-to-end architecture hardening | 16 | 16 |
| Pure reducer Phase 8 — final compatibility removal | 10 | 10 |
| CSV validation | 11 | 11 |
| **Total** | **103** | **103** |

All nine suites were run individually against the alpha8 application. All checks passed.

## Phase 8 coverage

- No global property accessors remain for the former compatibility state fields.
- Runtime reads use explicit selectors and writes use reducer-backed actions.
- Selector/action state is authoritative; invalid index and mode changes are rejected.
- Start, reveal, next, previous, and restart preserve behavior.
- Pause/resume retains consistent lesson and timer state.
- Stop/continue restores the saved question.
- Completion state and completion screen work; replay returns to the first question.
- Review subset starts in Revision mode at the first selected question.
- Navigation invalidates obsolete narration callbacks.
- No browser page errors in the focused Phase 8 suite.

## Additional checks

- `node --check` on the extracted application JavaScript: passed.
- Manual Playwright smoke test: Start → Reveal → Next completed without page errors.
- Reset Settings smoke test: returned reducer state to idle/question/answer-hidden without page errors.
- ZIP integrity and release-manifest hashes: verified.

## Limitations

These are focused regression checks, not exhaustive certification across every browser/device. Speech tests validate sequencing and stale-callback handling with controlled utterance mocks; they do not certify audible pronunciation or voice availability. External CSV URL/CORS behavior and long-duration timer behavior are not exhaustively tested.
