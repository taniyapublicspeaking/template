# Question Presenter v1.3.0-alpha8

A standalone HTML/CSS/JavaScript classroom question presenter. Open `question-presenter-v1.3.0-alpha8.html` in a modern browser; no framework or build step is required.

## Final compatibility-removal pass

- Removed the `Object.defineProperties(globalThis, ...)` compatibility layer for `list`, `i`, `mode`, `phase`, `revealed`, `explanationVisible`, `running`, and `paused`.
- Replaced core lesson reads with explicit selectors: `selectQuestions`, `selectQuestionIndex`, `selectMode`, `selectQuestionPhase`, `selectAnswerVisible`, `selectExplanationVisible`, `selectIsRunning`, and `selectIsPaused`.
- Replaced legacy setter-style writes with explicit reducer-backed commands: `replaceQuestions`, `setQuestionIndex`, `setLearningMode`, `setQuestionPhase`, `setAnswerVisible`, and `setExplanationVisible`.
- Preserved the single state-commit boundary and existing lesson command gateway.
- Kept timer, speech, delayed callbacks, CSV validation, review, replay, and completion behavior under regression coverage.

## Learning features

Timed Quiz, Teacher-Led, Self-Paced, and Revision modes; CSV question bank loading and validation; question navigation; pause/resume; stop/continue checkpoints; narration controls; completion/replay; focused review; and presentation mode.

## Regression tests

See `TEST-REPORT.md` and `tests/`. The suites are executable Python scripts using Playwright with local Chromium. Run them individually from this directory, for example:

```bash
python tests/test_pure_reducer_phase8.py
```

The nine suites cover reducer phases 1–8 and CSV validation. Native speech output, external CSV CORS behavior, and long-duration timing are not exhaustively certified across every browser/device.
