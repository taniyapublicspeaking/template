# Question Presenter v1.3.0-alpha6

Standalone HTML/CSS/JavaScript classroom question presenter. Open `question-presenter-v1.3.0-alpha6.html` in a modern browser; no framework or build step is required.

## Phase 6 — Reducer-authoritative state

- The reducer is now authoritative for the question bank, question index, learning mode, question phase, answer/explanation visibility, lesson lifecycle, session identity, timing metadata, error state, and checkpoints.
- Removed duplicated mutable globals for `list`, `i`, `mode`, `phase`, `revealed`, `explanationVisible`, `running`, and `paused`. Existing rendering/effect code temporarily accesses reducer-backed properties; those properties do not store a second copy of the values.
- Added reducer actions for question-bank replacement, session identity, question-session advancement, timing updates, and checkpoint/error updates.
- Removed direct writes to session/timing/checkpoint/error fields outside the reducer.
- Replaced the old `syncLessonState` mirror with `syncEffectState`, which updates only timer/delay/checkpoint observations through reducer actions and no longer mirrors core lesson fields.
- Removed the generic `LESSON/TRANSITION` compatibility action. Lifecycle transitions use explicit reducer actions such as `LESSON/START`, `LESSON/BEGIN`, `LESSON/PAUSE`, `LESSON/RESUME`, `LESSON/STOP`, `LESSON/CONTINUE`, `LESSON/COMPLETE`, and `LESSON/RESET`.
- Preserved the Phase 1–5 timer guards, speech lifecycle, narration sequencing, question navigation, CSV validation, and continue-from-checkpoint behavior.

## Regression tests

See `TEST-REPORT.md` and `tests/`. The tests use Playwright with local Chromium. They verify reducer immutability, navigation, lifecycle, timer ownership, speech cancellation/sequencing, Phase 6 removal checks, CSV validation, and browser-level core controls.

## Architecture note

Phase 6 removes duplicate storage and the generic lifecycle/synchronization adapters, but retains a small set of reducer-backed property accessors so existing effect/rendering functions can be migrated without a risky full rewrite. Those accessors are compatibility seams, not separate state stores. Further migration can replace remaining direct property-style reads/writes with explicit selectors/actions.
