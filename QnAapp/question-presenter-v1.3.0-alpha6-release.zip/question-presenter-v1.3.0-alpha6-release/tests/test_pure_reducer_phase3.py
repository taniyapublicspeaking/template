from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'question-presenter-v1.3.0-alpha6.html').read_text()
needle = '})();\n</script>'
assert needle in SRC
SRC = SRC.replace(needle, 'window.__reducerTest = { lessonReducer, getState: () => lessonState, dispatchLessonCommand, transitionLesson } ;\n})();\n</script>', 1)
HTML = Path('/tmp/question-presenter-v1.3.0-alpha6-phase3-test.html')
HTML.write_text(SRC)
results=[]
def check(name, fn):
    try: results.append((name, 'PASS', str(fn())))
    except Exception as e: results.append((name, 'FAIL', str(e)))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page()
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(HTML.read_text(), wait_until='domcontentloaded')

    def setup():
        page.set_content(HTML.read_text(), wait_until='domcontentloaded')
        page.locator('#mode').select_option('teacher')
        page.locator('#start').click()
        page.wait_for_selector('.question', timeout=3000)
        page.wait_for_function("() => window.__reducerTest.getState().status === 'running'", timeout=3000)

    def test_reducer_start_begin():
        r=page.evaluate('''() => {const {lessonReducer,getState}=window.__reducerTest; const s=getState(); const idle={...s,status:'idle',questions:[{},{}],questionIndex:0}; const starting=lessonReducer(idle,{type:'LESSON/START'}); const running=lessonReducer(starting,{type:'LESSON/BEGIN'}); const invalid=lessonReducer(running,{type:'LESSON/START'}); return {starting:starting.status,running:running.status,invalidStartNoop:invalid===running,original:idle.status};}''')
        assert r=={'starting':'starting','running':'running','invalidStartNoop':True,'original':'idle'},r
        return r

    def test_reducer_pause_resume():
        r=page.evaluate('''() => {const {lessonReducer,getState}=window.__reducerTest; const s={...getState(),status:'running',timer:{...getState().timer,status:'running'}}; const p=lessonReducer(s,{type:'LESSON/PAUSE'}); const r=lessonReducer(p,{type:'LESSON/RESUME'}); const bad=lessonReducer(p,{type:'LESSON/PAUSE'}); return {paused:p.status,timerPaused:p.timer.status,resumed:r.status,timerResumed:r.timer.status,repeatPauseNoop:bad===p,original:s.status};}''')
        assert r=={'paused':'paused','timerPaused':'paused','resumed':'running','timerResumed':'running','repeatPauseNoop':True,'original':'running'},r
        return r

    def test_reducer_stop_continue_requires_checkpoint():
        r=page.evaluate('''() => {const {lessonReducer,getState}=window.__reducerTest; const s={...getState(),status:'running',questions:[{},{}],checkpoint:{available:false,savedAt:null,snapshot:null}}; const bad=lessonReducer(s,{type:'LESSON/CONTINUE'}); const stopped=lessonReducer(s,{type:'LESSON/STOP',savedAt:'now',snapshot:{questionIndex:1}}); const continued=lessonReducer(stopped,{type:'LESSON/CONTINUE'}); return {invalidContinueNoop:bad===s,stopped:stopped.status,checkpointRetained:stopped.checkpoint.snapshot.questionIndex,continued:continued.status,checkpointPreservedForRestore:continued.checkpoint.snapshot.questionIndex,original:s.status};}''')
        assert r=={'invalidContinueNoop':True,'stopped':'stopped','checkpointRetained':1,'continued':'running','checkpointPreservedForRestore':1,'original':'running'},r
        return r

    def test_reducer_completion_decision():
        r=page.evaluate('''() => {const {lessonReducer,getState}=window.__reducerTest; const base={...getState(),status:'running',questions:[{},{},{}],questionIndex:1}; const early=lessonReducer(base,{type:'LESSON/COMPLETE',finishedAt:10}); const final={...base,questionIndex:2}; const done=lessonReducer(final,{type:'LESSON/COMPLETE',finishedAt:20}); return {earlyRejected:early===base,status:done.status,phase:done.question.phase,timer:done.timer.status,finishedAt:done.timing.finishedAt,sourceUnchanged:final.status==='running'};}''')
        assert r=={'earlyRejected':True,'status':'completed','phase':'complete','timer':'idle','finishedAt':20,'sourceUnchanged':True},r
        return r

    def test_browser_start():
        setup()
        s=page.evaluate('window.__reducerTest.getState().status')
        assert s=='running',s
        return 'Start enters reducer-owned running state'

    def test_browser_pause_resume():
        setup()
        page.locator('#pause').click()
        assert page.evaluate('window.__reducerTest.getState().status')=='paused'
        page.locator('#pause').click()
        assert page.evaluate('window.__reducerTest.getState().status')=='running'
        return 'Pause and Resume update reducer lifecycle state'

    def test_browser_stop():
        setup()
        page.locator('#next').click()
        page.locator('#stop').click()
        s=page.evaluate('''() => {const s=window.__reducerTest.getState();return {status:s.status,index:s.checkpoint.snapshot.questionIndex,available:s.checkpoint.available};}''')
        assert s=={'status':'stopped','index':1,'available':True},s
        return s

    def test_browser_continue():
        setup()
        page.locator('#next').click()
        page.locator('#stop').click()
        page.locator('#resume').click()
        s=page.evaluate('''() => {const s=window.__reducerTest.getState();return {status:s.status,index:s.questionIndex,checkpoint:s.checkpoint.snapshot};}''')
        assert s=={'status':'running','index':1,'checkpoint':None},s
        assert 'Question 2 of' in page.locator('.progressline').inner_text()
        return s

    def test_browser_completion():
        setup()
        result=page.evaluate("() => window.__reducerTest.dispatchLessonCommand('GO_TO_QUESTION',{index:5})")
        assert result['ok'] is True, result
        page.locator('#next').click()
        s=page.evaluate('''() => {const s=window.__reducerTest.getState();return {status:s.status,phase:s.question.phase,timer:s.timer.status,doneVisible:!document.querySelector('#done').classList.contains('hidden')};}''')
        assert s=={'status':'completed','phase':'complete','timer':'idle','doneVisible':True},s
        return s

    check('Reducer Start and Begin decisions', test_reducer_start_begin)
    check('Reducer Pause and Resume decisions', test_reducer_pause_resume)
    check('Reducer Stop and checkpoint-gated Continue decisions', test_reducer_stop_continue_requires_checkpoint)
    check('Reducer rejects premature completion and accepts final-question completion', test_reducer_completion_decision)
    check('Browser Start behaviour', test_browser_start)
    check('Browser Pause and Resume behaviour', test_browser_pause_resume)
    check('Browser Stop preserves checkpoint', test_browser_stop)
    check('Browser Continue restores saved question and clears checkpoint', test_browser_continue)
    check('Browser lesson completion decision and completion screen', test_browser_completion)
    check('No browser page errors', lambda: (errors if not errors else (_ for _ in ()).throw(AssertionError(errors))) or 'none')
    browser.close()

for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'SUMMARY: {sum(x[1]=="PASS" for x in results)}/{len(results)} passed')
if any(x[1]=='FAIL' for x in results): raise SystemExit(1)
