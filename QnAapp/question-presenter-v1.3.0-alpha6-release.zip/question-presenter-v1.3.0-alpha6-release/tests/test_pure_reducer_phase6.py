from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'question-presenter-v1.3.0-alpha6.html').read_text()
needle = '})();\n</script>'
assert needle in SRC
SRC = SRC.replace(needle, '''window.__phase6 = {
  lessonReducer, getState:()=>lessonState, applyLessonAction, syncEffectState,
  transitionLesson, start, pause, next, go, reveal, stop, resume, finish,
  getQuestion:()=>cur(), getAsync:()=>({running,paused,listIndex:i,phase,revealed,explanationVisible,mode})
};
})();
</script>''', 1)
HTML = Path('/tmp/question-presenter-v1.3.0-alpha6-phase6-test.html')
HTML.write_text(SRC)
results=[]
def check(name, fn):
    try: results.append((name, 'PASS', str(fn())))
    except Exception as e: results.append((name, 'FAIL', str(e)))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page()
    errors=[]; page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(HTML.read_text(), wait_until='domcontentloaded')
    def test_source_has_no_duplicated_core_let_bindings():
        declaration=SRC.split('let bank=bankSample.slice()',1)[1].split(';',1)[0]
        assert not any(x in declaration for x in ['list=[]','i=0','mode="timed"','running=false','paused=false','revealed=false','phase="question"']), declaration
        assert 'let explanationVisible = false' not in SRC
        assert 'syncLessonState' not in SRC and 'case \"LESSON/TRANSITION\"' not in SRC
        for direct_write in ['lessonState.sessionId=', 'lessonState.questionSessionId++;', 'lessonState.timing.pausedAt=', 'lessonState.checkpoint.snapshot=', 'lessonState.error=']:
            assert direct_write not in SRC, direct_write
        return 'Core lesson fields are not independently declared as mutable runtime variables'
    def test_question_bank_setter_updates_authoritative_state():
        r=page.evaluate('''() => {const t=window.__phase6, q=[{question:'A'},{question:'B'}];window.list=q;const s=t.getState();return {sameArray:s.questions===q,copyLength:s.questions.length,index:s.questionIndex,qid:s.questionSessionId,phase:s.question.phase};}''')
        assert r=={'sameArray':False,'copyLength':2,'index':0,'qid':1,'phase':'question'},r
        return r
    def test_index_setter_uses_reducer_validation():
        r=page.evaluate('''() => {window.i=1;const good=window.__phase6.getState().questionIndex;window.i=99;return {good,after:window.__phase6.getState().questionIndex};}''')
        assert r=={'good':1,'after':1},r; return r
    def test_mode_setter_updates_reducer_state():
        r=page.evaluate('''() => {window.mode='teacher';const a=window.__phase6.getState().mode;window.mode='not-a-mode';return {accepted:a,rejected:window.__phase6.getState().mode};}''')
        assert r=={'accepted':'teacher','rejected':'teacher'},r; return r
    def test_phase_and_visibility_are_reducer_backed():
        r=page.evaluate('''() => {window.phase='answer';window.revealed=true;window.explanationVisible=true;return window.__phase6.getState().question;}''')
        assert r=={'phase':'answer','answerVisible':True,'explanationVisible':True},r; return r
    def test_lifecycle_flags_are_derived_not_mutable_copies():
        r=page.evaluate('''() => {const a=Object.getOwnPropertyDescriptor(window,'running'),b=Object.getOwnPropertyDescriptor(window,'paused');return {runningGetter:typeof a.get==='function',runningSetter:typeof a.set,pausedGetter:typeof b.get==='function',pausedSetter:typeof b.set};}''')
        assert r=={'runningGetter':True,'runningSetter':'undefined','pausedGetter':True,'pausedSetter':'undefined'},r; return r
    def test_generic_transition_compatibility_action_removed():
        case_removed='case \"LESSON/TRANSITION\"' not in SRC
        r=page.evaluate('''() => {const t=window.__phase6,s=t.getState();return {actionNoop:t.lessonReducer(s,{type:'LESSON/TRANSITION',status:'starting'})===s};}''')
        assert case_removed and r=={'actionNoop':True},(case_removed,r); return {'caseRemoved':case_removed,**r}
    def test_sync_only_updates_effect_observations():
        r=page.evaluate('''() => {const t=window.__phase6;window.list=[{question:'One'},{question:'Two'}];window.i=1;window.mode='self';window.phase='answer';window.revealed=true;const before=t.getState();t.syncEffectState();const after=t.getState();return {index:after.questionIndex,mode:after.mode,phase:after.question.phase,visible:after.question.answerVisible,questions:after.questions.length,identityChanged:after!==before};}''')
        assert r=={'index':1,'mode':'self','phase':'answer','visible':True,'questions':2,'identityChanged':True},r; return r
    def test_browser_start_reveal_next_preserves_ui_and_state():
        page.set_content(HTML.read_text(), wait_until='domcontentloaded')
        page.locator('#start').click()
        assert page.locator('.question').inner_text(timeout=3000)
        page.locator('#reveal').click()
        assert page.locator('.answer').count()==1
        a=page.evaluate('''() => ({index:window.__phase6.getState().questionIndex,phase:window.__phase6.getState().question.phase,visible:window.__phase6.getState().question.answerVisible})''')
        page.locator('#next').click()
        b=page.evaluate('''() => ({index:window.__phase6.getState().questionIndex,phase:window.__phase6.getState().question.phase,visible:window.__phase6.getState().question.answerVisible})''')
        assert a=={'index':0,'phase':'answer','visible':True} and b=={'index':1,'phase':'question','visible':False},(a,b)
        return {'revealed':a,'next':b}
    def test_pause_stop_continue_lifecycle_without_runtime_copies():
        page.set_content(HTML.read_text(), wait_until='domcontentloaded')
        page.locator('#start').click(); page.locator('#next').click(); page.locator('#pause').click()
        paused=page.evaluate('''() => ({status:window.__phase6.getState().status,running,paused})''')
        page.locator('#stop').click()
        stopped=page.evaluate('''() => ({status:window.__phase6.getState().status,running,paused,checkpoint:window.__phase6.getState().checkpoint.available})''')
        page.locator('#resume').click()
        resumed=page.evaluate('''() => ({status:window.__phase6.getState().status,running,paused,index:window.__phase6.getState().questionIndex})''')
        assert paused=={'status':'paused','running':True,'paused':True},paused
        assert stopped=={'status':'stopped','running':False,'paused':False,'checkpoint':True},stopped
        assert resumed=={'status':'running','running':True,'paused':False,'index':1},resumed
        return {'paused':paused,'stopped':stopped,'resumed':resumed}
    def test_reducer_state_is_not_overwritten_by_legacy_sync():
        r=page.evaluate('''() => {const t=window.__phase6;window.list=[{question:'X'},{question:'Y'}];window.i=1;window.mode='teacher';window.revealed=true;const state=t.getState();t.syncEffectState();return {sameCore:state.questions===t.getState().questions && state.questionIndex===t.getState().questionIndex && state.mode===t.getState().mode && state.question.answerVisible===t.getState().question.answerVisible};}''')
        assert r['sameCore'] is True,r; return 'Effect synchronization does not overwrite reducer-owned core fields'
    check('Core state has no duplicated mutable bindings',test_source_has_no_duplicated_core_let_bindings)
    check('Question bank setter updates authoritative reducer state',test_question_bank_setter_updates_authoritative_state)
    check('Question index setter uses reducer validation',test_index_setter_uses_reducer_validation)
    check('Mode setter updates reducer state',test_mode_setter_updates_reducer_state)
    check('Phase and visibility setters are reducer-backed',test_phase_and_visibility_are_reducer_backed)
    check('Running and paused are derived lifecycle flags',test_lifecycle_flags_are_derived_not_mutable_copies)
    check('Generic lifecycle compatibility action is removed',test_generic_transition_compatibility_action_removed)
    check('Sync updates only effect observations, not core state',test_sync_only_updates_effect_observations)
    check('Start/reveal/next browser behavior preserved',test_browser_start_reveal_next_preserves_ui_and_state)
    check('Pause/stop/continue behavior preserved without copies',test_pause_stop_continue_lifecycle_without_runtime_copies)
    check('Legacy synchronization cannot overwrite reducer core fields',test_reducer_state_is_not_overwritten_by_legacy_sync)
    check('No browser page errors',lambda: (errors if not errors else (_ for _ in ()).throw(AssertionError(errors))) or 'none')
    browser.close()
for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'SUMMARY: {sum(x[1]=="PASS" for x in results)}/{len(results)} passed')
if any(x[1]=='FAIL' for x in results): raise SystemExit(1)
