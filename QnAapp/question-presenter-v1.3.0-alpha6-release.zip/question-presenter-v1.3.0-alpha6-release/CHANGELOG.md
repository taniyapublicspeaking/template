# Changelog

## v1.3.0-alpha6 — Phase 6: Reducer-authoritative state

- Removed duplicate mutable runtime variables for question bank, index, mode, phase, visibility, and lifecycle flags.
- Added reducer actions for question-bank replacement, session identity, question-session advancement, timing updates, and checkpoint/error updates.
- Routed session identity, timing, checkpoint, and error updates through reducer actions rather than direct nested state mutation.
- Replaced `syncLessonState` with `syncEffectState`; core lesson fields are no longer copied from legacy globals into reducer state.
- Removed the generic `LESSON/TRANSITION` reducer action and its lifecycle compatibility fallback.
- Added 12 Phase 6 regression tests and updated the earlier lifecycle test to assert explicit reducer actions.
- Re-ran all Phase 1–6 and CSV-validation suites: 77/77 tests passed.

## v1.3.0-alpha5 — Phase 5: Speech and Narration Effects

- Centralized browser speech operations behind `SpeechEffects`.
- Added reducer-validated speech start, pause, resume, end, cancel, and error transitions.
- Guarded speech callbacks with lesson session, question session, and speech sequence identity.
- Protected answer-then-explanation order and invalidated delayed narration after navigation.
