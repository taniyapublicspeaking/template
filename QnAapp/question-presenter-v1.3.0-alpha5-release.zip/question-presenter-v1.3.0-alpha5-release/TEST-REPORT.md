# Test Report — Question Presenter v1.3.0-alpha5

**Environment:** Playwright + local Chromium (`/usr/bin/chromium`), Python test runners, Node.js syntax check.

## Results

| Suite | Result |
|---|---:|
| Pure reducer Phase 1 | 6/6 passed |
| Pure reducer Phase 2 | 10/10 passed |
| Pure reducer Phase 3 | 10/10 passed |
| Pure reducer Phase 4 | 13/13 passed |
| CSV validation | 11/11 passed |
| Pure reducer Phase 5 — speech/narration | 15/15 passed |
| **Total** | **65/65 passed** |

## Phase 5 coverage

- Reducer accepts current speech start/end transitions.
- Reducer rejects obsolete session, question, and utterance-sequence events.
- Reducer accepts cancellation that advances the speech sequence.
- Speech effects dispatch state changes through reducer actions.
- Utterance completion returns speech state to idle.
- Obsolete `onend` and `onerror` callbacks cannot mutate the next question.
- Cancellation advances the sequence, invokes browser cancellation, and invalidates late callbacks.
- Pause/resume transitions speech state through reducer actions.
- Answer narration precedes explanation narration.
- A delayed explanation is not spoken after navigation to another question.
- No browser page errors in the Phase 5 suite.

## Additional checks

- JavaScript syntax check: passed.
- ZIP integrity check: passed.
- Release manifest file sizes and SHA-256 hashes: verified.

## Limitations

This is a focused regression suite, not exhaustive certification across browsers/devices. Phase 5 tests use a controlled speech-utterance mock, so they verify callback/state sequencing rather than audible pronunciation, voice availability, or platform-specific speech synthesis behavior. External CSV URL/CORS behavior and long-duration timing were not exhaustively retested.
