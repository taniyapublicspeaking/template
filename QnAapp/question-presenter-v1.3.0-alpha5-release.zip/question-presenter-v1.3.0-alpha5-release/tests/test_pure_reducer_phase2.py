from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'question-presenter-v1.3.0-alpha5.html').read_text()
needle = '})();\n</script>'
assert needle in SRC
SRC = SRC.replace(needle, 'window.__reducerTest = { lessonReducer, getState: () => lessonState, dispatchLessonCommand, commitQuestionAction };\n})();\n</script>', 1)
HTML = Path('/tmp/question-presenter-v1.3.0-alpha5-test.html')
HTML.write_text(SRC)
results=[]
def check(name, fn):
    try:
        results.append((name, 'PASS', str(fn())))
    except Exception as e:
        results.append((name, 'FAIL', str(e)))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page()
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(HTML.read_text(), wait_until='domcontentloaded')

    def setup():
        page.set_content(HTML.read_text(), wait_until='domcontentloaded')
        page.locator('#mode').select_option('teacher')
        page.locator('#start').click()
        page.wait_for_selector('.question', timeout=3000)
        page.wait_for_function("() => window.__reducerTest.getState().status === 'running'", timeout=3000)

    def test_nav_reducer_immutable():
        setup()
        r=page.evaluate('''() => { const {lessonReducer,getState}=window.__reducerTest; const s=getState(); const before=JSON.stringify(s); const n=lessonReducer(s,{type:'QUESTION/NAVIGATE',index:1}); return {newRoot:n!==s,originalUnchanged:JSON.stringify(s)===before,index:n.questionIndex,phase:n.question.phase,answerVisible:n.question.answerVisible,sessionAdvanced:n.questionSessionId===s.questionSessionId+1}; }''')
        assert r == {'newRoot':True,'originalUnchanged':True,'index':1,'phase':'question','answerVisible':False,'sessionAdvanced':True}, r
        return r

    def test_invalid_nav_rejected():
        setup()
        r=page.evaluate('''() => { const {lessonReducer,getState}=window.__reducerTest; const s=getState(); return [-1, s.questions.length, 1.5, 'not-a-number'].map(index => lessonReducer(s,{type:'QUESTION/NAVIGATE',index})===s); }''')
        assert all(r), r
        return 'Negative, out-of-range, fractional, and nonnumeric indices rejected'

    def test_reveal_reducer():
        setup()
        r=page.evaluate('''() => { const {lessonReducer,getState}=window.__reducerTest; const s=getState(); const n=lessonReducer(s,{type:'QUESTION/REVEAL'}); const again=lessonReducer(n,{type:'QUESTION/REVEAL'}); return {phase:n.question.phase,answerVisible:n.question.answerVisible,explanationVisible:n.question.explanationVisible,idempotent:again===n,originalHidden:!s.question.answerVisible}; }''')
        assert r == {'phase':'answer','answerVisible':True,'explanationVisible':False,'idempotent':True,'originalHidden':True}, r
        return r

    def test_restart_reducer():
        setup()
        page.evaluate("() => window.__reducerTest.dispatchLessonCommand('GO_TO_QUESTION',{index:2})")
        page.evaluate("() => window.__reducerTest.dispatchLessonCommand('REVEAL_ANSWER')")
        r=page.evaluate('''() => { const {lessonReducer,getState}=window.__reducerTest; const s=getState(); const n=lessonReducer(s,{type:'QUESTION/RESTART'}); return {sameIndex:n.questionIndex===s.questionIndex,index:n.questionIndex,phase:n.question.phase,answerVisible:n.question.answerVisible,newRoot:n!==s,sessionAdvanced:n.questionSessionId===s.questionSessionId+1}; }''')
        assert r == {'sameIndex':True,'index':2,'phase':'question','answerVisible':False,'newRoot':True,'sessionAdvanced':True}, r
        return r

    def test_ui_next_previous():
        setup()
        page.locator('#next').click()
        assert 'Question 2 of' in page.locator('.progressline').inner_text()
        assert page.locator('.question').inner_text().strip() == 'Which part of a plant takes in water from the soil?'
        page.locator('#prev').click()
        assert 'Question 1 of' in page.locator('.progressline').inner_text()
        assert not page.locator('.answer').count()
        return 'Next and Previous update reducer index and displayed question'

    def test_ui_go_to_question():
        setup()
        r=page.evaluate("() => window.__reducerTest.dispatchLessonCommand('GO_TO_QUESTION',{index:3})")
        assert r['ok'] is True, r
        assert 'Question 4 of' in page.locator('.progressline').inner_text()
        assert page.locator('.question').inner_text().strip().startswith('What force can slow down')
        assert page.evaluate('window.__reducerTest.getState().questionIndex') == 3
        return 'GO_TO_QUESTION index is zero-based and updates UI/state'

    def test_ui_restart_question():
        setup()
        page.locator('#next').click()
        page.locator('#reveal').click()
        assert page.locator('.answer').count()==1
        page.locator('#restartQ').click()
        assert 'Question 2 of' in page.locator('.progressline').inner_text()
        assert page.locator('.answer').count()==0
        st=page.evaluate('''() => { const s=window.__reducerTest.getState(); return {index:s.questionIndex,phase:s.question.phase,visible:s.question.answerVisible}; }''')
        assert st=={'index':1,'phase':'question','visible':False},st
        return st

    def test_ui_reveal_answer():
        setup()
        page.locator('#reveal').click()
        assert page.locator('.answer').count()==1
        st=page.evaluate('''() => { const s=window.__reducerTest.getState(); return {phase:s.question.phase,visible:s.question.answerVisible}; }''')
        assert st=={'phase':'answer','visible':True},st
        return st

    def test_duplicate_reveal_noop():
        setup()
        page.locator('#reveal').click()
        s1=page.evaluate('window.__reducerTest.getState().questionSessionId')
        page.evaluate("() => window.__reducerTest.dispatchLessonCommand('REVEAL_ANSWER')")
        assert page.locator('.answer').count()==1
        s2=page.evaluate('window.__reducerTest.getState().questionSessionId')
        assert s1==s2
        return 'Repeated reveal does not create another state transition'

    check('Reducer navigation creates immutable reset state', test_nav_reducer_immutable)
    check('Reducer rejects invalid navigation indices', test_invalid_nav_rejected)
    check('Reducer reveal updates answer phase and is idempotent', test_reveal_reducer)
    check('Reducer restart resets visibility without changing index', test_restart_reducer)
    check('Browser Next and Previous regression', test_ui_next_previous)
    check('Browser Go to Question regression', test_ui_go_to_question)
    check('Browser Restart Question regression', test_ui_restart_question)
    check('Browser Reveal Answer regression', test_ui_reveal_answer)
    check('Repeated Reveal Answer is safe', test_duplicate_reveal_noop)
    check('No browser page errors', lambda: (errors if not errors else (_ for _ in ()).throw(AssertionError(errors))) or 'none')
    browser.close()

for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'SUMMARY: {sum(x[1]=="PASS" for x in results)}/{len(results)} passed')
if any(x[1]=='FAIL' for x in results): raise SystemExit(1)
