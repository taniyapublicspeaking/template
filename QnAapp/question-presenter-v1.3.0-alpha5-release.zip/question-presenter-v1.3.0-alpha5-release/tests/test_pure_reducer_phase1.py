from pathlib import Path
from playwright.sync_api import sync_playwright
src=(Path(__file__).resolve().parents[1] / 'question-presenter-v1.3.0-alpha5.html').read_text()
needle='})();\n</script>'
assert needle in src
hook='''window.__reducerTest = { lessonReducer, initial: lessonState, transitionLesson, dispatchLessonCommand };\n})();\n</script>'''
src=src.replace(needle,hook,1)
test_html=Path('/tmp/question-presenter-alpha-test.html')
test_html.write_text(src)
results=[]
def check(name, fn):
    try:
        detail=fn(); results.append((name,'PASS',str(detail)))
    except Exception as e: results.append((name,'FAIL',str(e)))
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page()
    errors=[]; page.on('pageerror',lambda e: errors.append(str(e)))
    page.set_content(test_html.read_text(), wait_until='domcontentloaded')
    def test_transition_immutable():
        r=page.evaluate('''() => {const {lessonReducer,initial}=window.__reducerTest; const before=JSON.stringify(initial); const next=lessonReducer(initial,{type:'LESSON/TRANSITION',status:'starting'}); return {beforeUnchanged:JSON.stringify(initial)===before, newState:next!==initial, oldStatus:initial.status, newStatus:next.status};}''')
        assert r=={'beforeUnchanged':True,'newState':True,'oldStatus':'idle','newStatus':'starting'},r
        return r
    def test_invalid_transition_rejected():
        r=page.evaluate('''() => {const {lessonReducer,initial}=window.__reducerTest; return lessonReducer(initial,{type:'LESSON/TRANSITION',status:'completed'})===initial;}''')
        assert r is True
        return 'idle → completed rejected without changing state'
    def test_question_index_and_visibility():
        r=page.evaluate('''() => {const {lessonReducer,initial}=window.__reducerTest; const s={...initial,questions:[{},{},{}]}; const n=lessonReducer(s,{type:'QUESTION/SET_INDEX',index:2}); const bad=lessonReducer(n,{type:'QUESTION/SET_INDEX',index:9}); const v=lessonReducer(n,{type:'QUESTION/SET_VISIBILITY',answerVisible:true,explanationVisible:true}); return {index:n.questionIndex,invalidSame:bad===n,answerVisible:v.question.answerVisible,explanationVisible:v.question.explanationVisible,originalIndex:s.questionIndex};}''')
        assert r=={'index':2,'invalidSame':True,'answerVisible':True,'explanationVisible':True,'originalIndex':0},r
        return r
    def test_timer_nested_immutable():
        r=page.evaluate('''() => {const {lessonReducer,initial}=window.__reducerTest; const n=lessonReducer(initial,{type:'TIMER/UPDATE',value:{remainingMs:1234}}); return {newRoot:n!==initial,newTimer:n.timer!==initial.timer,old:initial.timer.remainingMs,new:n.timer.remainingMs};}''')
        assert r=={'newRoot':True,'newTimer':True,'old':30000,'new':1234},r
        return r
    for name,fn in [('Pure reducer returns a new state without mutating input',test_transition_immutable),('Invalid lifecycle transition is rejected',test_invalid_transition_rejected),('Question index and answer visibility actions',test_question_index_and_visibility),('Nested timer update preserves immutability',test_timer_nested_immutable)]: check(name,fn)
    def test_start_reveal_next_pause_stop_continue():
        page.locator('#start').click()
        assert page.locator('.question').inner_text(timeout=3000)
        page.locator('#reveal').click()
        assert page.locator('.answer').count()==1
        page.locator('#next').click()
        assert 'Question 2 of' in page.locator('.progressline').inner_text()
        page.locator('#pause').click()
        assert page.locator('#pause').inner_text().lower().find('resume')>=0
        page.locator('#stop').click()
        page.locator('#resume').click()
        assert 'Question 2 of' in page.locator('.progressline').inner_text()
        return 'Start, reveal, next, pause, stop and continue-from-current-question passed'
    check('Browser smoke test for core lesson controls',test_start_reveal_next_pause_stop_continue)
    check('No browser page errors',lambda: (errors if not errors else (_ for _ in ()).throw(AssertionError(errors))) or 'none')
    browser.close()
for n,s,d in results: print(f'{s}: {n} — {d}')
print(f'SUMMARY: {sum(x[1]=="PASS" for x in results)}/{len(results)} passed')
if any(x[1]=='FAIL' for x in results): raise SystemExit(1)
