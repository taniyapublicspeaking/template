# Question Presenter v1.3.0-alpha5

Standalone HTML/CSS/JavaScript classroom question presenter. No framework or build step is required.

## Phase 5 — Pure Reducer Architecture: Speech and narration effects

- Added reducer-owned speech lifecycle actions: `SPEECH/START`, `SPEECH/PAUSE`, `SPEECH/RESUME`, `SPEECH/END`, `SPEECH/CANCEL`, and `SPEECH/ERROR`.
- Centralized browser speech side effects behind `SpeechEffects`; the reducer remains free of DOM, timer, and speech APIs.
- Speech events are validated against lesson session ID, question session ID, and utterance sequence ID.
- Cancellation advances the speech sequence, cancels pending explanation delays, and makes callbacks from obsolete utterances inert.
- Pause/resume dispatch speech state transitions through the reducer while retaining browser speech pause/resume calls.
- Preserved answer-then-explanation narration sequencing and guards on delayed explanation playback.
- Kept prior timer ownership, stale timer callback protection, CSV validation, and lesson lifecycle behavior.

## Use

Open `question-presenter-v1.3.0-alpha5.html` in a modern browser. Browser speech support and available voices depend on the device and browser.

## Tests

See `TEST-REPORT.md`. Tests use Playwright with local Chromium. Speech regression tests use a controlled utterance mock to test lifecycle sequencing and stale callback rejection; they do not certify audible speech quality across every browser/device.
