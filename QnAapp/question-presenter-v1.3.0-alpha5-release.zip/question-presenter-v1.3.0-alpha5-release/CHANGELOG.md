# Changelog

## v1.3.0-alpha5 — Phase 5: Speech and Narration Effects

- Added reducer-validated speech start, pause, resume, end, cancel, and error transitions.
- Centralized browser speech API operations in the `SpeechEffects` adapter.
- Guarded speech callbacks with lesson session, question session, and speech sequence identity.
- Invalidated pending utterances and explanation-delay callbacks on cancellation or question navigation.
- Preserved answer-then-explanation narration order and pause/resume behavior.
- Added 15 focused Phase 5 regression tests.
- Re-ran Phases 1–4 and CSV validation regression suites against this release.

## v1.3.0-alpha4

- Added reducer-validated timer ticks and expiry with timer generation and lesson/question ownership checks.
- Guarded timer, question-delay, speech-delay, and learning-stage callbacks against stale session/question contexts.
