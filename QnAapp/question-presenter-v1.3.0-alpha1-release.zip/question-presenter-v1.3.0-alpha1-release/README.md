# Question Presenter v1.3.0-alpha1

Standalone HTML application using plain HTML, CSS, and JavaScript.

## Run
Open `question-presenter-v1.3.0-alpha1.html` in a modern browser. No build step or framework is required.

## Phase 1 architecture notes
`lessonReducer(state, action)` is a pure state transition function. It does not manipulate the DOM, schedule timers, or speak. `transitionLesson()` now delegates lifecycle transition decisions to the reducer and then updates legacy runtime aliases as a compatibility adapter.

This is the first incremental migration step. The app is not yet fully reducer-driven: commands and side effects are still handled by existing runtime functions.

## Tests
- `tests/test_pure_reducer_phase1.py`: reducer immutability, transition validation, question state updates, timer nested immutability, core browser control smoke test, and browser error check.
- `tests/test_csv_validation.py`: inherited CSV validation regression suite.

The tests use Python Playwright and local Chromium (`/usr/bin/chromium`). Run with:

```bash
python tests/test_pure_reducer_phase1.py
python tests/test_csv_validation.py
```
