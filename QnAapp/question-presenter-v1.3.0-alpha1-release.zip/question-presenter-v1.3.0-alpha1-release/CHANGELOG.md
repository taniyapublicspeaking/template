# Changelog — Question Presenter v1.3.0-alpha1

## Pure Reducer Architecture — Phase 1
- Added a side-effect-free `lessonReducer(state, action)`.
- Added immutable reducer actions for lifecycle transitions, question index, answer/explanation visibility, question phase, learning mode, timer state, speech state, delay state, checkpoint state, and errors.
- Migrated lifecycle transition validation to the reducer, retaining `transitionLesson()` as a compatibility/effect adapter for the existing runtime.
- Preserved existing CSV validation fixes from v1.2.1.

## Scope and limitations
This is an incremental architecture foundation, not a completed reducer migration. Most lifecycle operations, timers, speech, DOM rendering, and legacy state aliases still run through existing command functions. Those will be migrated in later phases with regression tests at each step.
